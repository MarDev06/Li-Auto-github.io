import React from 'react';
import { motion } from 'motion/react';
import { Search, Bell, User, Zap, MessageSquare, UserPlus, Clock, Shield, BarChart3, Database, Mail, Filter } from 'lucide-react';

export default function MockDashboard() {
  return (
    <div className="w-full aspect-[16/10] bg-surface-container-low rounded-3xl overflow-hidden border border-outline-variant/20 shadow-2xl flex flex-col">
      {/* Top Bar */}
      <div className="h-12 bg-white border-b border-outline-variant/10 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <div className="w-6 h-6 primary-gradient rounded flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          <div className="w-32 h-2 bg-slate-100 rounded-full"></div>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 bg-slate-50 rounded-full"></div>
          <div className="w-6 h-6 bg-slate-50 rounded-full"></div>
          <div className="w-16 h-6 bg-primary/10 rounded-full"></div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Sidebar */}
        <div className="w-16 bg-white border-r border-outline-variant/10 flex flex-col items-center py-6 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className={`w-8 h-8 rounded-lg ${i === 1 ? 'bg-primary/10 text-primary' : 'bg-slate-50 text-slate-300'} flex items-center justify-center`}>
              <div className="w-4 h-4 bg-current rounded-sm opacity-50"></div>
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 p-6 space-y-6 overflow-hidden">
          <div className="flex justify-between items-center">
            <div className="space-y-2">
              <div className="w-48 h-4 bg-slate-200 rounded-full"></div>
              <div className="w-32 h-2 bg-slate-100 rounded-full"></div>
            </div>
            <div className="w-24 h-8 primary-gradient rounded-lg"></div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white p-4 rounded-xl border border-outline-variant/5 shadow-sm space-y-3">
                <div className="w-8 h-8 rounded-lg bg-primary/5"></div>
                <div className="w-full h-2 bg-slate-100 rounded-full"></div>
                <div className="w-2/3 h-2 bg-slate-50 rounded-full"></div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl border border-outline-variant/5 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-32 h-3 bg-slate-200 rounded-full"></div>
              <div className="flex gap-2">
                <div className="w-4 h-4 bg-slate-100 rounded"></div>
                <div className="w-4 h-4 bg-slate-100 rounded"></div>
              </div>
            </div>
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex items-center gap-4 py-2 border-b border-slate-50 last:border-0">
                  <div className="w-8 h-8 rounded-full bg-slate-100"></div>
                  <div className="flex-1 space-y-2">
                    <div className="w-1/3 h-2 bg-slate-100 rounded-full"></div>
                    <div className="w-1/4 h-1.5 bg-slate-50 rounded-full"></div>
                  </div>
                  <div className="w-12 h-4 bg-green-50 rounded-full"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function MockScraper() {
  return (
    <div className="bg-white p-6 rounded-3xl shadow-xl border border-outline-variant/10 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
            <Search className="w-5 h-5" />
          </div>
          <h4 className="font-bold">LinkedIn Search</h4>
        </div>
        <div className="px-3 py-1 bg-primary text-white text-[10px] font-bold rounded-full uppercase">Scraping...</div>
      </div>
      <div className="space-y-3">
        {[1, 2, 3].map(i => (
          <motion.div 
            key={i}
            initial={{ x: -10, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
            className="flex items-center gap-4 p-3 bg-slate-50 rounded-xl border border-slate-100"
          >
            <div className="w-8 h-8 rounded-full bg-slate-200"></div>
            <div className="flex-1 space-y-2">
              <div className="w-24 h-2 bg-slate-300 rounded-full"></div>
              <div className="w-16 h-1.5 bg-slate-200 rounded-full"></div>
            </div>
            <div className="w-4 h-4 text-green-500">
              <Zap className="w-4 h-4 fill-current" />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function MockEnrichment() {
  return (
    <div className="bg-white p-6 rounded-3xl shadow-xl border border-outline-variant/10 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-secondary/10 text-secondary flex items-center justify-center">
          <Database className="w-5 h-5" />
        </div>
        <h4 className="font-bold">Data Enrichment</h4>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
          <Mail className="w-5 h-5 text-blue-500 mb-2" />
          <div className="text-[10px] font-bold text-blue-400 uppercase">Emails Found</div>
          <div className="text-2xl font-black text-blue-600">1,284</div>
        </div>
        <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
          <Filter className="w-5 h-5 text-purple-500 mb-2" />
          <div className="text-[10px] font-bold text-purple-400 uppercase">Verified</div>
          <div className="text-2xl font-black text-purple-600">98.2%</div>
        </div>
      </div>
      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
        <div className="flex justify-between items-center mb-2">
          <div className="text-[10px] font-bold text-slate-400 uppercase">Processing Queue</div>
          <div className="text-[10px] font-bold text-primary">85%</div>
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: '85%' }}
            className="h-full bg-primary"
          />
        </div>
      </div>
    </div>
  );
}

export function MockAnalytics() {
  return (
    <div className="bg-white p-6 rounded-3xl shadow-xl border border-outline-variant/10 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-green-100 text-green-600 flex items-center justify-center">
            <BarChart3 className="w-5 h-5" />
          </div>
          <h4 className="font-bold">Performance</h4>
        </div>
      </div>
      <div className="h-32 flex items-end gap-2 px-2">
        {[40, 70, 45, 90, 65, 80, 55].map((h, i) => (
          <motion.div 
            key={i}
            initial={{ height: 0 }}
            animate={{ height: `${h}%` }}
            transition={{ delay: i * 0.1 }}
            className="flex-1 bg-primary/20 rounded-t-lg relative group"
          >
            <div className="absolute inset-0 bg-primary rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity" />
          </motion.div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-50">
        <div>
          <div className="text-[10px] font-bold text-slate-400 uppercase">Reply Rate</div>
          <div className="text-xl font-black text-on-surface">24.5%</div>
        </div>
        <div>
          <div className="text-[10px] font-bold text-slate-400 uppercase">Connections</div>
          <div className="text-xl font-black text-on-surface">412</div>
        </div>
      </div>
    </div>
  );
}

export function MockWorkflow() {
  return (
    <div className="space-y-4">
      <motion.div 
        initial={{ x: -20, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        className="bg-white p-4 rounded-2xl shadow-lg border border-outline-variant/10 flex items-center gap-4"
      >
        <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
          <UserPlus className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <div className="w-24 h-2 bg-slate-200 rounded-full mb-2"></div>
          <div className="w-full h-1.5 bg-slate-100 rounded-full"></div>
        </div>
      </motion.div>

      <div className="flex justify-center">
        <div className="w-px h-8 bg-outline-variant/20"></div>
      </div>

      <motion.div 
        initial={{ x: 20, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-white p-4 rounded-2xl shadow-lg border border-outline-variant/10 flex items-center gap-4"
      >
        <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
          <Clock className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <div className="w-20 h-2 bg-slate-200 rounded-full mb-2"></div>
          <div className="w-3/4 h-1.5 bg-slate-100 rounded-full"></div>
        </div>
      </motion.div>

      <div className="flex justify-center">
        <div className="w-px h-8 bg-outline-variant/20"></div>
      </div>

      <motion.div 
        initial={{ x: -20, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="bg-primary p-4 rounded-2xl shadow-lg shadow-primary/20 flex items-center gap-4"
      >
        <div className="w-10 h-10 rounded-xl bg-white/20 text-white flex items-center justify-center">
          <MessageSquare className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <div className="w-28 h-2 bg-white/30 rounded-full mb-2"></div>
          <div className="w-full h-1.5 bg-white/10 rounded-full"></div>
        </div>
      </motion.div>
    </div>
  );
}

