import React from 'react';
import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';

interface PublicLayoutProps {
  children: React.ReactNode;
}

export default function PublicLayout({ children }: PublicLayoutProps) {
  return (
    <div className="min-h-screen bg-surface-container-lowest text-on-surface selection:bg-primary/30">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-surface-container-lowest/80 backdrop-blur-md border-b border-outline-variant/10">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 primary-gradient rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
                <Zap className="text-white w-6 h-6" />
              </div>
              <span className="text-xl font-headline font-black tracking-tighter uppercase text-primary">LinkedIn Automator</span>
            </Link>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <Link to="/features" className="text-sm font-bold text-on-surface-variant hover:text-primary transition-colors">Features</Link>
            <Link to="/how-it-works" className="text-sm font-bold text-on-surface-variant hover:text-primary transition-colors">How it Works</Link>
            <Link to="/pricing" className="text-sm font-bold text-on-surface-variant hover:text-primary transition-colors">Pricing</Link>
            <Link to="/help" className="text-sm font-bold text-on-surface-variant hover:text-primary transition-colors">Help</Link>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-sm font-bold hover:text-primary transition-colors">Log In</Link>
            <Link to="/login" className="px-6 py-2.5 primary-gradient text-white rounded-xl text-sm font-bold shadow-lg shadow-primary/20 hover:scale-105 transition-transform">
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      <main>
        {children}
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-outline-variant/10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 primary-gradient rounded-lg flex items-center justify-center">
              <Zap className="text-white w-5 h-5" />
            </div>
            <span className="font-headline font-black tracking-tighter uppercase text-primary">LinkedIn Automator</span>
          </div>
          <div className="flex gap-8 text-sm font-bold text-on-surface-variant">
            <Link to="/privacy" className="hover:text-primary">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-primary">Terms of Service</Link>
            <Link to="/help" className="hover:text-primary">Contact Us</Link>
          </div>
          <p className="text-sm text-on-surface-variant opacity-50">© 2026 LinkedIn Automator. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
