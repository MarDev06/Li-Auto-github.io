import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import TopBar from './TopBar';

export default function Layout() {
  return (
    <div className="min-h-screen bg-surface">
      <Sidebar />
      <div className="flex flex-col min-h-screen">
        <TopBar />
        <main className="ml-64 p-8 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
