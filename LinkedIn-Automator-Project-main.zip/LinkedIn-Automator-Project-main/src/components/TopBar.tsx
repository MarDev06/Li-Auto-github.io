import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Search, Bell, HelpCircle, User, ChevronRight, X, Zap } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export default function TopBar() {
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);

  const pathnames = location.pathname.split('/').filter((x) => x);

  const mockResults = [
    { title: 'Sarah Jenkins', type: 'Lead', path: '/app/leads' },
    { title: 'Enterprise Outreach', type: 'Campaign', path: '/app/campaigns' },
    { title: 'Smart Delays', type: 'Setting', path: '/app/settings' },
  ].filter(r => r.title.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <header className="sticky top-0 z-40 w-full flex justify-between items-center px-8 h-16 glass-panel border-b border-outline-variant/10 ml-64">
      <div className="flex items-center gap-6 flex-1">
        {/* Breadcrumbs */}
        <nav className="hidden md:flex items-center gap-2 text-xs font-bold text-on-surface-variant uppercase tracking-widest">
          <Link to="/app" className="hover:text-primary transition-colors">App</Link>
          {pathnames.map((name, index) => {
            if (name === 'app' && index === 0) return null; // Skip 'app' in breadcrumbs if it's the first part
            const routeTo = `/${pathnames.slice(0, index + 1).join('/')}`;
            const isLast = index === pathnames.length - 1;
            return (
              <div key={name} className="flex items-center gap-2">
                <ChevronRight className="w-3 h-3 text-outline-variant" />
                <Link
                  to={routeTo}
                  className={cn(
                    "transition-colors",
                    isLast ? "text-primary" : "hover:text-primary"
                  )}
                >
                  {name.replace(/-/g, ' ')}
                </Link>
              </div>
            );
          })}
        </nav>

        {/* Search */}
        <div className="relative max-w-md w-full ml-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-outline-variant w-4 h-4" />
          <input
            className="w-full bg-surface-container-low border-none rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-primary/20 transition-all outline-none"
            placeholder="Search leads, campaigns, settings..."
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowResults(e.target.value.length > 0);
            }}
            onFocus={() => searchQuery && setShowResults(true)}
          />
          {searchQuery && (
            <button 
              onClick={() => { setSearchQuery(''); setShowResults(false); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-outline-variant hover:text-on-surface"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Search Results Dropdown */}
          {showResults && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-surface-container-lowest border border-outline-variant/10 rounded-xl shadow-xl overflow-hidden animate-in fade-in slide-in-from-top-2">
              <div className="p-2">
                {mockResults.length > 0 ? (
                  mockResults.map((result, i) => (
                    <Link
                      key={i}
                      to={result.path}
                      onClick={() => setShowResults(false)}
                      className="flex items-center justify-between p-3 hover:bg-surface-container-low rounded-lg transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-primary/5 text-primary flex items-center justify-center">
                          <Zap className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-on-surface group-hover:text-primary">{result.title}</p>
                          <p className="text-[10px] text-on-surface-variant uppercase font-bold tracking-widest">{result.type}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-outline-variant" />
                    </Link>
                  ))
                ) : (
                  <div className="p-8 text-center">
                    <p className="text-sm text-on-surface-variant italic">No results found for "{searchQuery}"</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-4">
          <Link to="/app/notifications" className="text-slate-500 hover:text-primary transition-all opacity-80 hover:opacity-100 relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          </Link>
          <Link to="/help" className="text-slate-500 hover:text-primary transition-all opacity-80 hover:opacity-100">
            <HelpCircle className="w-5 h-5" />
          </Link>
        </div>
        <div className="h-8 w-[1px] bg-outline-variant/30"></div>
        <Link to="/app/account" className="flex items-center gap-3 group">
          <div className="text-right">
            <p className="text-xs font-bold text-on-surface font-headline group-hover:text-primary transition-colors">Alex Chen</p>
            <p className="text-[10px] text-outline-variant">Pro Plan</p>
          </div>
          <img
            className="w-8 h-8 rounded-full border-2 border-white shadow-sm group-hover:border-primary/50 transition-all"
            alt="User Profile"
            referrerPolicy="no-referrer"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuB5X0X4hUc2FOFJgHOVNZRrqykHRfCy0GIw5JGPcjtAqBg2bo86om1BUfhFj9gQatXpYF6NxPFjZqc-CYbeg0CsG-fnhKBp03UHRMYdGtNdq-PoIqn4t0cBS8vU8GJ7WUkbsVvAQ3BnW5-VpNvAlLG_B-uGtxgPW68K2LhcwO43UCl9H_vOWE4Xf8r3ZnRRzlN1MEEI5XC9EHqCx40m4BMH5f_vib2Lztbhb1PfB0DV4-WCNcQ1-j3OZ6BH86wZs27xsLBKL2PkFKs"
          />
        </Link>
      </div>
    </header>
  );
}
