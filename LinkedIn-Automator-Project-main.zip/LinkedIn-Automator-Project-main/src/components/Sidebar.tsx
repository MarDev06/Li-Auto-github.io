import { NavLink, Link, useNavigate } from 'react-router-dom';
import { cn } from '@/src/lib/utils';
import { LogOut } from 'lucide-react';

const sections = [
  {
    title: 'Core',
    items: [
      { label: 'Dashboard', path: '/app', materialIcon: 'dashboard', end: true },
      { label: 'Campaigns', path: '/app/campaigns', materialIcon: 'account_tree' },
      { label: 'Leads', path: '/app/leads', materialIcon: 'group' },
    ]
  },
  {
    title: 'Analytics',
    items: [
      { label: 'Insights', path: '/app/insights', materialIcon: 'auto_awesome' },
      { label: 'Activity Logs', path: '/app/activity', materialIcon: 'history' },
    ]
  },
  {
    title: 'System',
    items: [
      { label: 'Notifications', path: '/app/notifications', materialIcon: 'notifications' },
      { label: 'Settings', path: '/app/settings', materialIcon: 'settings_applications' },
    ]
  },
  {
    title: 'Account',
    items: [
      { label: 'Pricing', path: '/pricing', materialIcon: 'payments' },
      { label: 'Account', path: '/app/account', materialIcon: 'account_circle' },
      { label: 'Help Center', path: '/help', materialIcon: 'help' },
    ]
  }
];

export default function Sidebar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    navigate('/');
  };

  return (
    <aside className="fixed left-0 top-0 h-full flex flex-col py-6 w-64 bg-slate-50 dark:bg-slate-900 z-50 border-r border-outline-variant/10">
      <div className="px-6 mb-10 flex items-center gap-3">
        <Link to="/app" className="flex items-center gap-3">
          <div className="w-10 h-10 primary-gradient rounded-lg flex items-center justify-center text-white shadow-lg shadow-primary/20">
            <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>rocket_launch</span>
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#0077B5] leading-tight font-headline">LinkedIn Automator</h2>
            <p className="text-[10px] font-bold tracking-widest uppercase text-outline-variant opacity-70">Premium SaaS</p>
          </div>
        </Link>
      </div>

      <div className="flex-1 px-4 space-y-8 overflow-y-auto custom-scrollbar">
        {sections.map((section) => (
          <div key={section.title}>
            <h3 className="px-4 text-[10px] font-bold uppercase tracking-widest text-outline-variant mb-2 opacity-60">
              {section.title}
            </h3>
            <nav className="space-y-1">
              {section.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-150 ease-in-out group",
                      isActive
                        ? "bg-primary/10 text-primary font-bold shadow-sm"
                        : "text-slate-600 dark:text-slate-400 font-medium hover:bg-slate-100 dark:hover:bg-slate-800/50"
                    )
                  }
                >
                  <span className={cn(
                    "material-symbols-outlined text-xl transition-colors",
                    "group-hover:text-primary"
                  )}>
                    {item.materialIcon}
                  </span>
                  <span className="font-sans text-sm">{item.label}</span>
                </NavLink>
              ))}
            </nav>
          </div>
        ))}
      </div>

      <div className="mt-auto px-4 pt-6 space-y-2 border-t border-outline-variant/5">
        <Link to="/app/campaigns/new" className="w-full primary-gradient text-white py-3 rounded-xl font-bold shadow-lg shadow-primary/20 flex items-center justify-center gap-2 hover:scale-[1.02] transition-all active:scale-95">
          <span className="material-symbols-outlined text-sm">add</span>
          <span className="text-sm">New Campaign</span>
        </Link>
        <button 
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-red-500 font-bold hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm">Logout</span>
        </button>
      </div>
    </aside>
  );
}
