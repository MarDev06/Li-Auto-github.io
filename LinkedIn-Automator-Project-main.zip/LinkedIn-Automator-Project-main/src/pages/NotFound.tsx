import { Link } from 'react-router-dom';
import { Home, Compass, Map } from 'lucide-react';
import { motion } from 'motion/react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-surface-container-lowest flex items-center justify-center p-6 text-center">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md"
      >
        <div className="relative mb-12">
          <h1 className="text-[12rem] font-headline font-black leading-none text-primary/5 select-none">404</h1>
          <div className="absolute inset-0 flex items-center justify-center">
            <Compass className="w-32 h-32 text-primary animate-pulse" />
          </div>
        </div>
        
        <h2 className="text-4xl font-headline font-black tracking-tight mb-4">Page Not Found</h2>
        <p className="text-on-surface-variant mb-10 leading-relaxed">
          The page you are looking for doesn't exist. It might have been moved or deleted.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/" className="px-8 py-4 primary-gradient text-white rounded-2xl font-bold shadow-xl shadow-primary/20 hover:scale-105 transition-transform flex items-center justify-center gap-2">
            <Home className="w-5 h-5" /> Back Home
          </Link>
          <Link to="/help" className="px-8 py-4 bg-surface-container-high text-on-surface rounded-2xl font-bold hover:bg-slate-200 transition-colors flex items-center justify-center gap-2">
            <Map className="w-5 h-5" /> Help Center
          </Link>
        </div>
        
        <div className="mt-16 pt-8 border-t border-outline-variant/10">
          <p className="text-xs text-on-surface-variant font-mono uppercase tracking-widest opacity-50">
            Error Code: PAGE_NOT_FOUND_404
          </p>
        </div>
      </motion.div>
    </div>
  );
}
