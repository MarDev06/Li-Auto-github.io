import { Sparkles, TrendingUp, Target, Zap, ChevronRight, ArrowUpRight, Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useState } from 'react';

const insights = [
  {
    id: 1,
    title: 'High-Converting Persona',
    desc: 'Leads with the title "Principal Architect" are responding at a 35% higher rate than "Senior Architect".',
    type: 'Success',
    icon: Target,
    color: 'text-green-500',
    bg: 'bg-green-50',
  },
  {
    id: 2,
    title: 'Optimal Sending Time',
    desc: 'Your messages sent between 9:00 AM and 11:00 AM EST have the highest open rates.',
    type: 'Optimization',
    icon: Zap,
    color: 'text-primary',
    bg: 'bg-primary/5',
  },
  {
    id: 3,
    title: 'Messaging Insight',
    desc: 'Including a reference to "infrastructure overhaul" in your connection note increases acceptance by 12%.',
    type: 'Strategy',
    icon: Sparkles,
    color: 'text-purple-500',
    bg: 'bg-purple-50',
  },
];

export default function Insights() {
  const [applying, setApplying] = useState<number | null>(null);
  const [applied, setApplied] = useState<number[]>([]);

  const handleApply = (id: number) => {
    setApplying(id);
    setTimeout(() => {
      setApplying(null);
      setApplied(prev => [...prev, id]);
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-12">
        <h2 className="text-3xl font-headline font-extrabold text-on-surface tracking-tight">Automator Insights</h2>
        <p className="text-on-surface-variant mt-1">AI-driven strategic recommendations to optimize your outreach performance.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {insights.map((insight) => (
          <div key={insight.id} className="bg-surface-container-lowest p-8 rounded-3xl border border-outline-variant/10 shadow-sm flex flex-col">
            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center mb-6", insight.bg, insight.color)}>
              <insight.icon className="w-6 h-6" />
            </div>
            <div className="mb-2 flex items-center justify-between">
              <span className={cn("text-[10px] font-bold uppercase tracking-widest", insight.color)}>{insight.type}</span>
              <ArrowUpRight className="w-4 h-4 text-on-surface-variant" />
            </div>
            <h3 className="text-lg font-bold mb-3">{insight.title}</h3>
            <p className="text-sm text-on-surface-variant leading-relaxed flex-1">{insight.desc}</p>
            <button 
              disabled={applying === insight.id || applied.includes(insight.id)}
              onClick={() => handleApply(insight.id)}
              className={cn(
                "mt-8 w-full py-3 transition-all rounded-xl text-sm font-bold flex items-center justify-center gap-2",
                applied.includes(insight.id) 
                  ? "bg-green-100 text-green-700 cursor-default" 
                  : "bg-surface-container-low hover:bg-primary hover:text-white"
              )}
            >
              {applying === insight.id ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Applying...
                </>
              ) : applied.includes(insight.id) ? (
                <>
                  <span className="material-symbols-outlined text-sm">check_circle</span>
                  Applied
                </>
              ) : (
                'Apply Recommendation'
              )}
            </button>
          </div>
        ))}
      </div>

      <div className="bg-slate-900 rounded-3xl p-10 text-white relative overflow-hidden">
        <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/20 rounded-full text-primary text-[10px] font-bold uppercase tracking-widest mb-4">
              <Sparkles className="w-3 h-3" />
              AI Prediction
            </div>
            <h3 className="text-3xl font-bold mb-4">Projected Growth</h3>
            <p className="text-slate-400 leading-relaxed mb-8">
              Based on your current optimization trends, we project a <span className="text-primary font-bold">42% increase</span> in qualified leads over the next 30 days if you apply the suggested persona targeting.
            </p>
            <div className="flex gap-4">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                <p className="text-2xl font-black text-white">124</p>
                <p className="text-[10px] text-slate-500 uppercase font-bold">New Leads</p>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                <p className="text-2xl font-black text-primary">8.4%</p>
                <p className="text-[10px] text-slate-500 uppercase font-bold">Conv. Rate</p>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square bg-primary/10 rounded-full blur-3xl absolute inset-0"></div>
            <div className="relative bg-white/5 border border-white/10 p-8 rounded-3xl backdrop-blur-sm">
              <div className="flex items-end gap-2 mb-8">
                {[40, 60, 45, 90, 75, 100].map((h, i) => (
                  <div key={i} className="flex-1 bg-primary rounded-t-lg transition-all hover:scale-110 cursor-pointer" style={{ height: `${h}%` }}></div>
                ))}
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-bold uppercase tracking-widest">
                <span>Week 1</span>
                <span>Week 6</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
