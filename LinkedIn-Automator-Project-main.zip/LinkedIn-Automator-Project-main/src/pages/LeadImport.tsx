import { Upload, Link as LinkIcon, FileText, AlertCircle, CheckCircle2, ChevronRight, Download, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '@/src/lib/utils';

export default function LeadImport() {
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  const handleUpload = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      navigate('/app/leads');
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-10">
        <nav className="flex items-center gap-2 text-xs font-medium text-on-surface-variant mb-2">
          <Link to="/app/leads" className="hover:text-primary transition-colors">Leads</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-primary font-bold">Import Leads</span>
        </nav>
        <h2 className="text-3xl font-headline font-extrabold text-on-surface tracking-tight">Import New Leads</h2>
        <p className="text-on-surface-variant mt-1">Add new prospects to your database via CSV upload or LinkedIn URL list.</p>
      </div>

      <div className="grid md:grid-cols-12 gap-8">
        <div className="md:col-span-8">
          <div 
            onClick={!isProcessing ? handleUpload : undefined}
            className={cn(
              "bg-surface-container-lowest p-10 rounded-3xl border-2 border-dashed border-outline-variant/30 text-center hover:border-primary/50 transition-all group",
              isProcessing ? "cursor-wait opacity-80" : "cursor-pointer"
            )}
          >
            <div className="w-20 h-20 rounded-2xl bg-primary/5 text-primary flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              {isProcessing ? <Loader2 className="w-10 h-10 animate-spin" /> : <Upload className="w-10 h-10" />}
            </div>
            <h3 className="text-xl font-bold mb-2">{isProcessing ? 'Processing File...' : 'Upload CSV or Excel File'}</h3>
            <p className="text-on-surface-variant text-sm mb-8 max-w-sm mx-auto">
              {isProcessing ? 'We are analyzing your file and extracting lead data. This will only take a moment.' : 'Drag and drop your file here, or click to browse. Supports .csv, .xls, and .xlsx formats.'}
            </p>
            {!isProcessing && (
              <button className="px-10 py-3 bg-primary text-white font-bold rounded-xl shadow-lg shadow-primary/20 hover:opacity-90 transition-opacity">
                Select File
              </button>
            )}
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">
            <div className="p-6 rounded-2xl bg-surface-container-lowest border border-outline-variant/10 hover:border-primary/30 transition-all cursor-pointer">
              <LinkIcon className="w-6 h-6 text-primary mb-3" />
              <h4 className="font-bold text-sm">LinkedIn URL List</h4>
              <p className="text-xs text-on-surface-variant mt-1">Paste a list of profile URLs to scrape and enrich.</p>
            </div>
            <div className="p-6 rounded-2xl bg-surface-container-lowest border border-outline-variant/10 hover:border-primary/30 transition-all cursor-pointer">
              <FileText className="w-6 h-6 text-primary mb-3" />
              <h4 className="font-bold text-sm">Sales Navigator Link</h4>
              <p className="text-xs text-on-surface-variant mt-1">Import directly from a Sales Navigator search result.</p>
            </div>
          </div>
        </div>

        <div className="md:col-span-4 space-y-6">
          <div className="bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/10 shadow-sm">
            <h4 className="font-bold text-sm mb-4">Import Guidelines</h4>
            <ul className="space-y-4">
              {[
                { icon: CheckCircle2, text: 'Include "LinkedIn URL" for best results', color: 'text-green-500' },
                { icon: CheckCircle2, text: 'Max 5,000 leads per import', color: 'text-green-500' },
                { icon: AlertCircle, text: 'Ensure column headers are clear', color: 'text-amber-500' },
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <item.icon className={cn("w-4 h-4 mt-0.5 shrink-0", item.color)} />
                  <span className="text-xs text-on-surface-variant leading-tight">{item.text}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-slate-900 rounded-2xl p-6 text-white">
            <h4 className="font-bold text-sm mb-2">Need a template?</h4>
            <p className="text-xs text-slate-400 mb-4">Download our sample CSV to ensure your data is formatted correctly.</p>
            <button className="w-full py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-2">
              <Download className="w-4 h-4" />
              Download Template
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
