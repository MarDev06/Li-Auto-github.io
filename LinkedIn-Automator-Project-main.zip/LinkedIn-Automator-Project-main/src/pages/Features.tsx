import React from 'react';
import { motion } from 'motion/react';
import { Zap, Globe, Users, MessageSquare, Shield, BarChart3, CheckCircle2, ArrowRight } from 'lucide-react';
import PublicLayout from '@/src/components/PublicLayout';
import { Link } from 'react-router-dom';
import MockDashboard from '@/src/components/MockDashboard';

const features = [
  {
    icon: Zap,
    title: 'Smart Scraper',
    description: 'Extract high-quality leads from LinkedIn search results with one click. Our scraper handles pagination and filters automatically.',
    details: [
      'Bulk export to CSV or JSON',
      'Automatic duplicate detection',
      'Industry-specific filtering',
      'Background processing'
    ]
  },
  {
    icon: Globe,
    title: 'Email Discovery',
    description: 'Find verified work emails for any lead automatically. We use multiple data sources to ensure high deliverability.',
    details: [
      '98% verification accuracy',
      'Real-time SMTP checks',
      'Catch-all detection',
      'Domain-level enrichment'
    ]
  },
  {
    icon: Users,
    title: 'Auto-Connect',
    description: 'Send personalized connection requests with smart templates that bypass the "I don\'t know this person" filters.',
    details: [
      'Custom delay intervals',
      'Personalized invite notes',
      'Automatic withdrawal of old requests',
      'Daily limit management'
    ]
  },
  {
    icon: MessageSquare,
    title: 'AI Personalization',
    description: 'Our AI analyzes LinkedIn profiles to write messages that sound like you. No more generic templates that get ignored.',
    details: [
      'Context-aware messaging',
      'Tone of voice matching',
      'Project-based references',
      'Multi-language support'
    ]
  },
  {
    icon: Shield,
    title: 'Safety First',
    description: 'Human-like behavior simulation to keep your account safe. We prioritize account longevity over raw speed.',
    details: [
      'Randomized click patterns',
      'IP rotation (Residential Proxies)',
      'Cloud-based execution',
      'Safety health monitoring'
    ]
  },
  {
    icon: BarChart3,
    title: 'Deep Analytics',
    description: 'Track every interaction and optimize your outreach strategy with real-time performance dashboards.',
    details: [
      'Reply rate tracking',
      'Conversion funnel analysis',
      'A/B testing for templates',
      'ROI reporting'
    ]
  }
];

export default function Features() {
  return (
    <PublicLayout>
      <div className="relative overflow-hidden pt-32 pb-24 px-6">
        {/* Background Decorative Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-5xl md:text-6xl font-headline font-black text-on-surface mb-6 tracking-tighter">
                Powerful tools for <br />
                <span className="text-primary">LinkedIn Growth.</span>
              </h1>
              <p className="text-on-surface-variant max-w-2xl mx-auto text-lg leading-relaxed font-medium">
                We've built the most comprehensive outreach suite specifically for professional networking and firm growth.
              </p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-10 rounded-[2.5rem] border border-outline-variant/10 hover:border-primary/30 transition-all group shadow-sm hover:shadow-2xl hover:shadow-primary/5"
              >
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-sm">
                  <feat.icon className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-headline font-bold mb-4">{feat.title}</h3>
                <p className="text-on-surface-variant leading-relaxed mb-8 font-medium">{feat.description}</p>
                
                <ul className="space-y-3">
                  {feat.details.map((detail, j) => (
                    <li key={j} className="flex items-center gap-3 text-sm text-on-surface-variant font-medium">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

          {/* Feature Deep Dive / Visual Section */}
          <div className="mt-32 space-y-32">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="text-4xl font-headline font-black mb-6">AI-Powered Personalization</h2>
                <p className="text-on-surface-variant text-lg leading-relaxed mb-8 font-medium">
                  Our AI doesn't just use placeholders. It reads the lead's profile, identifies their recent accomplishments, and crafts a message that demonstrates genuine interest in their work.
                </p>
                <div className="space-y-4">
                  <div className="p-4 bg-surface-container-low rounded-2xl border border-outline-variant/10">
                    <p className="text-xs font-bold text-primary uppercase tracking-widest mb-2">Lead Profile</p>
                    <p className="text-sm font-medium">"Recently completed the sustainable timber pavilion in Oslo. Passionate about low-carbon materials."</p>
                  </div>
                  <div className="p-4 bg-primary/5 rounded-2xl border border-primary/20">
                    <p className="text-xs font-bold text-primary uppercase tracking-widest mb-2">AI Generated Message</p>
                    <p className="text-sm font-medium italic">"Hi Sarah, I was really impressed by your timber pavilion in Oslo. Your approach to low-carbon materials is exactly what the industry needs..."</p>
                  </div>
                </div>
              </motion.div>
              <div className="relative">
                <MockDashboard />
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl border border-outline-variant/10 animate-bounce">
                  <Zap className="w-8 h-8 text-primary" />
                </div>
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="order-2 lg:order-1 relative">
                <div className="bg-white p-8 rounded-[3rem] shadow-2xl border border-outline-variant/10">
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
                        <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                          <Shield className="w-5 h-5" />
                        </div>
                        <div className="flex-1 h-2 bg-slate-200 rounded-full"></div>
                        <div className="w-16 h-4 bg-green-100 rounded-full"></div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="order-1 lg:order-2"
              >
                <h2 className="text-4xl font-headline font-black mb-6">Account Safety is Priority #1</h2>
                <p className="text-on-surface-variant text-lg leading-relaxed mb-8 font-medium">
                  We've built LinkedIn Automator to be the safest automation tool on the market. We use residential proxies and randomized behavior to ensure your account remains in good standing.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 bg-surface-container-low rounded-2xl border border-outline-variant/10">
                    <h4 className="font-bold mb-2">Residential Proxies</h4>
                    <p className="text-xs text-on-surface-variant">Your account always appears to be logging in from your local city.</p>
                  </div>
                  <div className="p-6 bg-surface-container-low rounded-2xl border border-outline-variant/10">
                    <h4 className="font-bold mb-2">Smart Limits</h4>
                    <p className="text-xs text-on-surface-variant">We automatically adjust sending speeds based on your account age.</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-32 bg-slate-900 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-4xl md:text-5xl font-headline font-black text-white mb-6">Ready to see it in action?</h2>
              <p className="text-slate-400 text-lg mb-10 max-w-xl mx-auto">Join the leading firms already using LinkedIn Automator.</p>
              <Link to="/login" className="inline-flex items-center gap-2 px-10 py-5 bg-white text-slate-900 rounded-2xl font-bold text-xl hover:bg-primary hover:text-white transition-all shadow-xl shadow-white/5">
                Start Your Free Trial <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] -mr-48 -mt-48"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 blur-[120px] -ml-48 -mb-48"></div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}

