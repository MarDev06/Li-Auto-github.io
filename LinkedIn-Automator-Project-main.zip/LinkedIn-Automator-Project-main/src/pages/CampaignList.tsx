import { Plus, Search, MoreVertical, Play, Pause, Edit2, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '@/src/lib/utils';
import { useState } from 'react';

const initialCampaigns = [
  { id: 1, name: 'LinkedIn Enterprise Architect Outreach', status: 'Active', leads: 428, replies: 52, conversions: 12, lastActive: '2h ago' },
  { id: 2, name: 'Bay Area Tech Leads - Q2', status: 'Paused', leads: 1202, replies: 84, conversions: 18, lastActive: '1d ago' },
  { id: 3, name: 'London Design Studios', status: 'Draft', leads: 0, replies: 0, conversions: 0, lastActive: '3d ago' },
];

export default function CampaignList() {
  const [campaigns, setCampaigns] = useState(initialCampaigns);

  const toggleStatus = (id: number) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === id) {
        if (c.status === 'Active') return { ...c, status: 'Paused' };
        if (c.status === 'Paused') return { ...c, status: 'Active' };
      }
      return c;
    }));
  };

  const deleteCampaign = (id: number) => {
    if (window.confirm('Are you sure you want to delete this campaign?')) {
      setCampaigns(prev => prev.filter(c => c.id !== id));
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-10">
        <div>
          <h2 className="text-3xl font-headline font-extrabold text-on-surface tracking-tight">Your Campaigns</h2>
          <p className="text-on-surface-variant mt-1">Manage and monitor your automated outreach sequences.</p>
        </div>
        <Link to="/app/campaigns/new" className="px-8 py-2.5 rounded-lg font-semibold text-white primary-gradient shadow-xl shadow-primary/30 hover:scale-[1.02] transition-transform flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Campaign
        </Link>
      </div>

      <div className="grid gap-4">
        {campaigns.map((campaign) => (
          <div key={campaign.id} className="bg-surface-container-lowest rounded-xl p-6 shadow-sm border border-outline-variant/10 hover:border-primary/30 transition-all group">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => toggleStatus(campaign.id)}
                  className={cn(
                    "w-12 h-12 rounded-lg flex items-center justify-center transition-all hover:scale-110",
                    campaign.status === 'Active' ? "bg-green-100 text-green-600" : 
                    campaign.status === 'Paused' ? "bg-amber-100 text-amber-600" : "bg-slate-100 text-slate-600"
                  )}
                >
                  <span className="material-symbols-outlined">
                    {campaign.status === 'Active' ? 'pause' : campaign.status === 'Paused' ? 'play_arrow' : 'edit_note'}
                  </span>
                </button>
                <div>
                  <h3 className="text-lg font-bold text-on-surface group-hover:text-primary transition-colors">{campaign.name}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className={cn(
                      "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded",
                      campaign.status === 'Active' ? "bg-green-100 text-green-700" : 
                      campaign.status === 'Paused' ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-700"
                    )}>
                      {campaign.status}
                    </span>
                    <span className="text-xs text-on-surface-variant">Last active {campaign.lastActive}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-8">
                <div className="text-center">
                  <p className="text-sm font-bold text-on-surface">{campaign.leads}</p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold">Leads</p>
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold text-on-surface">{campaign.replies}</p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold">Replies</p>
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold text-on-surface">{campaign.conversions}</p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold">Conversions</p>
                </div>
                <div className="flex items-center gap-2 ml-4">
                  <Link to={`/app/campaigns/${campaign.id}`} className="p-2 hover:bg-surface-container-high rounded-lg transition-colors text-on-surface-variant hover:text-primary">
                    <Edit2 className="w-4 h-4" />
                  </Link>
                  <button 
                    onClick={() => deleteCampaign(campaign.id)}
                    className="p-2 hover:bg-red-50 rounded-lg transition-colors text-on-surface-variant hover:text-red-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {campaigns.length === 0 && (
          <div className="text-center py-20 bg-surface-container-lowest rounded-xl border border-dashed border-outline-variant/30">
            <p className="text-on-surface-variant">No campaigns found. Create your first one to get started!</p>
            <Link to="/app/campaigns/new" className="mt-4 inline-flex items-center gap-2 text-primary font-bold hover:underline">
              <Plus className="w-4 h-4" />
              Create Campaign
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
