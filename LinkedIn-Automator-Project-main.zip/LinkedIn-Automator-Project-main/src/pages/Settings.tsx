import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export default function Settings() {
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      navigate('/app');
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header Section */}
      <div className="mb-10">
        <h2 className="text-3xl font-extrabold font-headline text-on-surface tracking-tight mb-2">Automation Settings</h2>
        <p className="text-on-surface-variant max-w-2xl">Configure your precision agents to handle repetitive tasks while maintaining your professional voice and safety limits.</p>
      </div>

      {/* Horizontal Tabs Navigation */}
      <div className="mb-8 border-b border-outline-variant/15 flex gap-8 items-end">
        <button className="relative pb-4 text-sm font-semibold text-[#0077B5] transition-all">
          Auto Connect
          <div className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-[#0077B5]"></div>
        </button>
        <button className="pb-4 text-sm font-medium text-on-surface-variant hover:text-primary transition-all">Profile Scraper</button>
        <button className="pb-4 text-sm font-medium text-on-surface-variant hover:text-primary transition-all">Auto Poster</button>
        <button className="pb-4 text-sm font-medium text-on-surface-variant hover:text-primary transition-all">Auto Commenter</button>
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Main Form Column */}
        <div className="lg:col-span-8 space-y-6">
          {/* Section: Connection Limits */}
          <section className="bg-surface-container-lowest rounded-xl p-8 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <span className="material-symbols-outlined text-primary">speed</span>
              <h3 className="font-headline font-bold text-lg">Auto Connect Limits</h3>
            </div>
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-semibold text-on-surface">Daily Limit</label>
                  <span className="px-3 py-1 bg-primary-fixed text-on-primary-fixed-variant rounded-lg text-xs font-bold">25 Requests</span>
                </div>
                <input className="w-full h-1.5 bg-surface-container-high rounded-lg appearance-none cursor-pointer accent-primary" max="50" min="1" type="range" defaultValue="25" />
                <div className="flex justify-between text-[10px] text-on-surface-variant font-sans uppercase tracking-tighter font-bold">
                  <span>Conservative (1)</span>
                  <span>Aggressive (50)</span>
                </div>
              </div>
              <div className="flex items-center justify-between py-4 border-t border-outline-variant/10">
                <div>
                  <h4 className="font-semibold text-on-surface">Personalized Notes</h4>
                  <p className="text-xs text-on-surface-variant">Attach a custom message to every request.</p>
                </div>
                <div className="relative inline-flex items-center cursor-pointer">
                  <input defaultChecked className="sr-only peer" type="checkbox" />
                  <div className="w-11 h-6 bg-surface-container-high peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </div>
              </div>
              <div className="space-y-3">
                <label className="text-sm font-semibold text-on-surface">Message Template</label>
                <textarea
                  className="w-full bg-surface-container-low border border-outline-variant/20 rounded-lg p-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none resize-none"
                  placeholder="Hi {first_name}, I saw your profile and thought our architectural backgrounds align perfectly..."
                  rows={4}
                ></textarea>
                <div className="flex gap-2">
                  <span className="px-2 py-1 bg-surface-container-high rounded text-[10px] font-medium text-on-surface-variant">{"{first_name}"}</span>
                  <span className="px-2 py-1 bg-surface-container-high rounded text-[10px] font-medium text-on-surface-variant">{"{company}"}</span>
                  <span className="px-2 py-1 bg-surface-container-high rounded text-[10px] font-medium text-on-surface-variant">{"{industry}"}</span>
                </div>
              </div>
            </div>
          </section>

          {/* Section: Safety Checks */}
          <section className="bg-surface-container-lowest rounded-xl p-8 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <span className="material-symbols-outlined text-primary">verified_user</span>
              <h3 className="font-headline font-bold text-lg">Safety & Intelligence</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-surface border border-outline-variant/10">
                <div className="flex items-center gap-3 mb-2">
                  <span className="material-symbols-outlined text-tertiary">timer</span>
                  <span className="font-semibold text-sm">Smart Delays</span>
                </div>
                <p className="text-xs text-on-surface-variant">Simulate human behavior with randomized 2-5 min intervals.</p>
              </div>
              <div className="p-4 rounded-lg bg-surface border border-outline-variant/10">
                <div className="flex items-center gap-3 mb-2">
                  <span className="material-symbols-outlined text-primary">do_not_disturb_on</span>
                  <span className="font-semibold text-sm">Cooldown Mode</span>
                </div>
                <p className="text-xs text-on-surface-variant">Pause all activity if account limits are approached.</p>
              </div>
            </div>
          </section>
        </div>

        {/* Secondary Info Column */}
        <div className="lg:col-span-4 space-y-6">
          {/* Preview Card */}
          <div className="primary-gradient rounded-xl p-6 text-white shadow-lg">
            <h4 className="font-headline font-bold mb-4 flex items-center gap-2">
              <Link to="/app/activity" className="hover:underline flex items-center gap-2">
                <span className="material-symbols-outlined text-sm">analytics</span>
                Live Forecast
              </Link>
            </h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="opacity-80">Projected Outreach</span>
                <span className="font-bold">175 / week</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="opacity-80">Safety Rating</span>
                <span className="px-2 py-0.5 bg-white/20 rounded font-bold">Excellent</span>
              </div>
              <div className="h-2 w-full bg-white/10 rounded-full mt-4">
                <div className="h-full w-4/5 bg-white rounded-full"></div>
              </div>
            </div>
          </div>

          {/* Quick Profile Settings */}
          <div className="bg-surface-container-high/50 rounded-xl p-6 backdrop-blur-sm border border-outline-variant/5">
            <h4 className="font-headline font-bold text-sm mb-4">Quick Profile Settings</h4>
            <div className="space-y-3">
              {[
                { label: 'Export Job History', checked: true },
                { label: 'Extract Education', checked: true },
                { label: 'Sync with CRM', checked: false },
              ].map((item, i) => (
                <label key={i} className="flex items-center gap-3 text-sm cursor-pointer">
                  <input defaultChecked={item.checked} className="w-4 h-4 rounded border-outline-variant text-primary focus:ring-primary" type="checkbox" />
                  <span className="text-on-surface-variant">{item.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Status Indicator */}
          <div className="bg-surface-container-lowest rounded-xl p-6 border border-primary/10 flex items-start gap-4">
            <div className="h-3 w-3 rounded-full bg-green-500 mt-1 animate-pulse"></div>
            <div>
              <span className="font-bold text-sm block">Agent Active</span>
              <p className="text-xs text-on-surface-variant mt-1">Currently monitoring LinkedIn for potential architecture leads in New York area.</p>
            </div>
          </div>

          {/* Image Asset */}
          <div className="rounded-xl overflow-hidden aspect-video relative group">
            <img
              alt="Network Nodes"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              referrerPolicy="no-referrer"
              src="https://picsum.photos/seed/network/600/400"
            />
            <div className="absolute inset-0 bg-primary/20 mix-blend-multiply"></div>
            <div className="absolute inset-0 p-4 flex flex-col justify-end bg-gradient-to-t from-slate-900/80 to-transparent">
              <span className="text-white text-[10px] font-bold uppercase tracking-widest">Logic Visualization</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Action Bar */}
      <div className="mt-12 flex justify-end items-center gap-4 py-6 border-t border-outline-variant/10">
        <Link to="/app" className="px-6 py-2.5 rounded-lg text-sm font-semibold text-on-surface hover:bg-surface-container-high transition-colors">Discard Changes</Link>
        <button 
          onClick={handleSave}
          disabled={saving}
          className="px-8 py-2.5 rounded-lg primary-gradient text-white text-sm font-bold shadow-md hover:translate-y-[-1px] active:translate-y-0 transition-all flex items-center justify-center min-w-[160px]"
        >
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
              Saving...
            </>
          ) : (
            'Save All Settings'
          )}
        </button>
      </div>
    </div>
  );
}
