import React from 'react';
import PublicLayout from '@/src/components/PublicLayout';
import { motion } from 'motion/react';

export default function Privacy() {
  return (
    <PublicLayout>
      <div className="pt-32 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl font-headline font-black mb-8">Privacy Policy</h1>
            <div className="prose prose-slate max-w-none space-y-6 text-on-surface-variant font-medium">
              <p>Last updated: April 13, 2026</p>
              
              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">1. Information We Collect</h2>
                <p>We collect information you provide directly to us when you create an account, use our services, or communicate with us. This may include your name, email address, and LinkedIn profile information.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">2. How We Use Your Information</h2>
                <p>We use the information we collect to provide, maintain, and improve our services, to process transactions, and to communicate with you about your account and our services.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">3. Data Security</h2>
                <p>We implement reasonable security measures to protect your information from unauthorized access, disclosure, alteration, or destruction. However, no method of transmission over the internet is 100% secure.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">4. Sharing of Information</h2>
                <p>We do not sell your personal information to third parties. We may share your information with service providers who perform services on our behalf, or when required by law.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">5. Cookies</h2>
                <p>We use cookies and similar technologies to track activity on our service and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">6. Your Rights</h2>
                <p>You have the right to access, update, or delete the personal information we have on you. You can do this through your account settings or by contacting us directly.</p>
              </section>
            </div>
          </motion.div>
        </div>
      </div>
    </PublicLayout>
  );
}
