import { Bell, Check, Trash2, Clock, Settings as SettingsIcon } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

const initialNotifications = [
  { id: 1, title: 'Campaign Completed', message: 'Your "London Design Studios" campaign has finished processing 500 leads.', time: '2h ago', read: false },
  { id: 2, title: 'New Reply Received', message: 'Sarah Jenkins replied to your connection request.', time: '5h ago', read: true },
  { id: 3, title: 'System Update', message: 'We have improved our LinkedIn scraping algorithm for better accuracy.', time: '1d ago', read: true },
  { id: 4, title: 'Credit Warning', message: 'You have used 80% of your monthly lead enrichment credits.', time: '2d ago', read: true },
];

export default function Notifications() {
  const [notifications, setNotifications] = useState(initialNotifications);

  const markAsRead = (id: number) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h2 className="text-3xl font-headline font-extrabold text-on-surface tracking-tight">Notifications</h2>
          <p className="text-on-surface-variant mt-1">Stay updated with your campaign progress and system alerts.</p>
        </div>
        <div className="flex gap-3 items-center">
          <Link to="/app/settings" className="p-2 text-on-surface-variant hover:text-primary transition-colors">
            <SettingsIcon className="w-5 h-5" />
          </Link>
          {notifications.some(n => !n.read) && (
            <button 
              onClick={markAllAsRead}
              className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold flex items-center gap-2 hover:opacity-90 transition-opacity shadow-lg shadow-primary/20"
            >
              <Check className="w-4 h-4" />
              Mark all as read
            </button>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {notifications.map((n) => (
          <div key={n.id} className={`p-6 rounded-2xl border transition-all ${n.read ? 'bg-surface-container-lowest border-outline-variant/10' : 'bg-primary/5 border-primary/20 shadow-sm'}`}>
            <div className="flex gap-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${n.read ? 'bg-slate-100 text-slate-500' : 'bg-primary text-white'}`}>
                <Bell className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                  <h3 className={`font-bold ${n.read ? 'text-on-surface' : 'text-primary'}`}>{n.title}</h3>
                  <span className="text-[10px] font-bold text-on-surface-variant uppercase flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {n.time}
                  </span>
                </div>
                <p className="text-sm text-on-surface-variant leading-relaxed">{n.message}</p>
                <div className="mt-4 flex gap-3">
                  {!n.read && (
                    <button 
                      onClick={() => markAsRead(n.id)}
                      className="flex items-center gap-1.5 text-xs font-bold text-primary hover:bg-primary/10 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Mark as read
                    </button>
                  )}
                  <button 
                    onClick={() => deleteNotification(n.id)}
                    className="flex items-center gap-1.5 text-xs font-bold text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg transition-colors ml-auto"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {notifications.length === 0 && (
          <div className="text-center py-20 bg-surface-container-lowest rounded-2xl border border-dashed border-outline-variant/30">
            <Bell className="w-12 h-12 text-outline-variant mx-auto mb-4 opacity-20" />
            <p className="text-on-surface-variant">No notifications yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
