import { cn } from '@/src/lib/utils';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { Plus, Trash2, Clock, MessageSquare, UserPlus, Edit2, ChevronRight } from 'lucide-react';

type StepType = 'connection' | 'wait' | 'message';

interface Step {
  id: string;
  type: StepType;
  title: string;
  value?: string;
  delay?: number;
}

const initialSteps: Step[] = [
  { id: '1', type: 'connection', title: 'Initial Connection Request', value: 'Hi {{first_name}}, I noticed your work at {{company}} on the recent infrastructure overhaul. Would love to connect!' },
  { id: '2', type: 'wait', title: 'Wait 2 Days', delay: 2 },
  { id: '3', type: 'message', title: 'Follow-up Message 1', value: 'Hi {{first_name}}, just checking in to see if you had a chance to look at my previous message.' },
];

export default function Campaigns() {
  const [steps, setSteps] = useState<Step[]>(initialSteps);

  const addStep = (type: StepType) => {
    const newId = Math.random().toString(36).substr(2, 9);
    let newStep: Step;
    
    if (type === 'wait') {
      newStep = { id: newId, type: 'wait', title: 'Wait 1 Day', delay: 1 };
    } else if (type === 'message') {
      newStep = { id: newId, type: 'message', title: `Follow-up Message ${steps.filter(s => s.type === 'message').length + 1}`, value: '' };
    } else {
      newStep = { id: newId, type: 'connection', title: 'Connection Request', value: '' };
    }
    
    setSteps([...steps, newStep]);
  };

  const removeStep = (id: string) => {
    setSteps(steps.filter(s => s.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Campaign Header */}
      <div className="flex justify-between items-end mb-12">
        <div>
          <nav className="flex items-center gap-2 text-xs font-sans text-on-surface-variant mb-2 uppercase tracking-widest font-bold">
            <Link to="/app/campaigns" className="hover:text-primary transition-colors">Campaigns</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-primary">New Outreach Flow</span>
          </nav>
          <h2 className="text-4xl font-headline font-extrabold text-on-surface tracking-tight">LinkedIn Enterprise Architect Outreach</h2>
          <p className="text-on-surface-variant mt-1 text-lg">Define your automated sequence logic and messaging triggers.</p>
        </div>
        <div className="flex gap-3">
          <Link to="/app/campaigns" className="px-6 py-2.5 rounded-lg font-semibold text-on-surface bg-surface-container-high hover:bg-surface-container-highest transition-colors flex items-center justify-center">Save Draft</Link>
          <Link to="/app/campaigns" className="px-8 py-2.5 rounded-lg font-semibold text-white primary-gradient shadow-xl shadow-primary/30 hover:scale-[1.02] transition-transform flex items-center justify-center">Launch Campaign</Link>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-8">
        {/* Flow Canvas */}
        <div className="col-span-8 space-y-8">
          {steps.map((step, index) => (
            <div key={step.id} className="flex flex-col items-center">
              {step.type === 'wait' ? (
                <div className="node-connector flex flex-col items-center w-full">
                  <div className="w-fit bg-surface-container-high px-6 py-2 rounded-full flex items-center gap-3 text-on-surface-variant border border-outline-variant/10 group">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm font-semibold">Wait {step.delay} Days</span>
                    <button onClick={() => removeStep(step.id)} className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-500">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="node-connector flex flex-col items-center w-full">
                  <div className="w-full bg-surface-container-lowest rounded-xl p-6 shadow-sm border-l-4 border-primary">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                          {step.type === 'connection' ? <UserPlus className="w-5 h-5" /> : <MessageSquare className="w-5 h-5" />}
                        </div>
                        <div>
                          <span className="text-[10px] font-sans font-bold text-primary uppercase tracking-widest">Step {index + 1}</span>
                          <h3 className="text-lg font-headline font-bold">{step.title}</h3>
                        </div>
                      </div>
                      <button onClick={() => removeStep(step.id)} className="text-slate-400 hover:text-red-500 transition-colors">
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="space-y-4">
                      <label className="block text-xs font-sans font-bold text-on-surface-variant uppercase tracking-tighter">
                        {step.type === 'connection' ? 'Personalized Invite Note (Max 300 chars)' : 'Message Content'}
                      </label>
                      <textarea
                        className="w-full bg-surface-container-low border-none rounded-lg p-4 text-sm focus:ring-2 focus:ring-primary/20 placeholder-slate-400 outline-none resize-none"
                        placeholder="Write your message here..."
                        defaultValue={step.value}
                        rows={step.type === 'connection' ? 3 : 4}
                      ></textarea>
                      <div className="flex gap-2">
                        <button className="px-3 py-1.5 rounded bg-surface-container-high text-[11px] font-bold text-on-surface-variant hover:bg-slate-200 transition-colors uppercase">Add {"{{first_name}}"}</button>
                        <button className="px-3 py-1.5 rounded bg-surface-container-high text-[11px] font-bold text-on-surface-variant hover:bg-slate-200 transition-colors uppercase">Add {"{{company}}"}</button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Add Step Button */}
          <div className="flex justify-center pt-8 gap-4">
            <button 
              onClick={() => addStep('wait')}
              className="px-4 py-2 rounded-lg border border-outline-variant/30 text-xs font-bold uppercase tracking-widest hover:bg-surface-container-low transition-colors flex items-center gap-2"
            >
              <Clock className="w-4 h-4" />
              Add Wait
            </button>
            <button 
              onClick={() => addStep('message')}
              className="px-4 py-2 rounded-lg border border-outline-variant/30 text-xs font-bold uppercase tracking-widest hover:bg-surface-container-low transition-colors flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              Add Message
            </button>
          </div>
        </div>

        {/* Configuration Sidebar */}
        <div className="col-span-4 space-y-6">
          {/* Targeting Card */}
          <section className="bg-surface-container-lowest rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <span className="material-symbols-outlined text-primary">target</span>
              <h3 className="font-headline font-bold text-lg">Targeting</h3>
            </div>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-surface-container-low border border-outline-variant/10 group cursor-pointer hover:bg-primary/5 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm font-bold">Top 500 Arch Firms</span>
                  <span className="material-symbols-outlined text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>check_circle</span>
                </div>
                <p className="text-xs text-on-surface-variant">428 Active Leads • Last updated 2h ago</p>
              </div>
              <div className="p-4 rounded-lg bg-surface border border-outline-variant/20 group cursor-pointer hover:border-primary/40 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm font-semibold text-slate-500">Tech Lead - Bay Area</span>
                  <span className="w-5 h-5 rounded-full border border-outline-variant"></span>
                </div>
                <p className="text-xs text-slate-400">1,202 Leads • Created Oct 12</p>
              </div>
              <Link to="/app/leads/import" className="w-full py-3 rounded-lg border border-dashed border-outline-variant text-on-surface-variant font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-colors flex items-center justify-center">
                Import New Lead List
              </Link>
            </div>
          </section>

          {/* Settings Card */}
          <section className="bg-surface-container-lowest rounded-xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <span className="material-symbols-outlined text-primary">settings_applications</span>
              <h3 className="font-headline font-bold text-lg">Campaign Settings</h3>
            </div>
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-sans font-bold text-on-surface-variant uppercase tracking-tighter mb-3">Sending Window</label>
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
                    <button
                      key={i}
                      className={cn(
                        "h-8 rounded text-[10px] font-bold",
                        i < 5 ? "bg-primary-container text-white" : "bg-surface-container-high text-slate-400"
                      )}
                    >
                      {day}
                    </button>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">From</span>
                    <span className="text-sm font-semibold">09:00 AM</span>
                  </div>
                  <div className="px-4 text-slate-300">→</div>
                  <div className="flex-1 text-right">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">To</span>
                    <span className="text-sm font-semibold">05:00 PM</span>
                  </div>
                </div>
              </div>
              <div className="pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-bold">Smart Rate Limiting</span>
                  <div className="w-10 h-5 bg-primary-container rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold">Track Link Clicks</span>
                  <div className="w-10 h-5 bg-primary-container rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Health Stats */}
          <section className="bg-slate-900 rounded-xl p-6 text-white shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <span className="material-symbols-outlined text-primary-fixed">bolt</span>
              <h3 className="font-headline font-bold">Sequence Estimate</h3>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400">Monthly Outreach</span>
                <span className="font-headline font-bold">~850 leads</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400">Est. Reply Rate</span>
                <span className="font-headline font-bold text-primary-fixed">12.4%</span>
              </div>
              <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                <div className="w-2/3 h-full bg-primary-fixed"></div>
              </div>
              <p className="text-[10px] text-slate-500 leading-relaxed">
                Based on your architectural persona and 2-day delay spacing.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
