import React from 'react';
import PublicLayout from '@/src/components/PublicLayout';
import { motion } from 'motion/react';

export default function Terms() {
  return (
    <PublicLayout>
      <div className="pt-32 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl font-headline font-black mb-8">Terms of Service</h1>
            <div className="prose prose-slate max-w-none space-y-6 text-on-surface-variant font-medium">
              <p>Last updated: April 13, 2026</p>
              
              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">1. Acceptance of Terms</h2>
                <p>By accessing or using LinkedIn Automator, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">2. Description of Service</h2>
                <p>LinkedIn Automator provides automation tools for LinkedIn outreach, lead generation, and data enrichment. Our services are designed to help professionals grow their networks efficiently and ethically.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">3. User Responsibilities</h2>
                <p>You are responsible for maintaining the security of your account and for all activities that occur under your account. You agree to use the service in compliance with LinkedIn's User Agreement and all applicable laws.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">4. Account Safety</h2>
                <p>While we implement safety features to protect your account, you acknowledge that using automation tools on third-party platforms carries inherent risks. LinkedIn Automator is not responsible for any actions taken by LinkedIn against your account.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">5. Subscription and Payments</h2>
                <p>Subscriptions are billed in advance on a monthly or annual basis. You can cancel your subscription at any time, but no refunds will be provided for partial months of service.</p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-on-surface mb-4">6. Limitation of Liability</h2>
                <p>LinkedIn Automator shall not be liable for any direct, indirect, incidental, special, or consequential damages resulting from the use or inability to use our services.</p>
              </section>
            </div>
          </motion.div>
        </div>
      </div>
    </PublicLayout>
  );
}
