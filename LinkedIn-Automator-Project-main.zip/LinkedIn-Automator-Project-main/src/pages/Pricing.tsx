import { Check, Zap, Shield, Globe, Users, Loader2, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/src/lib/utils';
import PublicLayout from '@/src/components/PublicLayout';
import { motion } from 'motion/react';

const plans = [
  {
    id: 'starter',
    name: 'Starter',
    price: '$29',
    description: 'Perfect for individual architects starting their outreach.',
    features: ['500 Lead Scrapes / mo', '100 Connection Requests / mo', 'Basic Email Discovery', 'Smart Delays'],
    button: 'Switch to Starter',
    current: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '$49',
    description: 'Our most popular plan for growing architectural firms.',
    features: ['2,500 Lead Scrapes / mo', '500 Connection Requests / mo', 'Advanced Enrichment', 'Smart Rate Limiting', 'Priority Support'],
    button: 'Current Plan',
    current: true,
    highlight: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: '$199',
    description: 'Custom solutions for large-scale architectural practices.',
    features: ['Unlimited Scrapes', 'Unlimited Connections', 'Dedicated Account Manager', 'Custom API Access', 'Team Collaboration'],
    button: 'Contact Sales',
    current: false,
  },
];

export default function Pricing() {
  const [upgrading, setUpgrading] = useState<string | null>(null);

  const handleUpgrade = (planId: string) => {
    if (planId === 'pro') return; // Already on pro
    setUpgrading(planId);
    setTimeout(() => {
      setUpgrading(null);
    }, 2000);
  };

  return (
    <PublicLayout>
      <div className="relative overflow-hidden pt-32 pb-24 px-6">
        {/* Background Decorative Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-5xl md:text-6xl font-headline font-black text-on-surface mb-6 tracking-tighter">
                Scale your outreach <br />
                <span className="text-primary">without the limits.</span>
              </h1>
              <p className="text-on-surface-variant max-w-2xl mx-auto text-lg leading-relaxed font-medium">
                Choose the plan that fits your firm's growth stage. All plans include our core safety features and human-like behavior simulation.
              </p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 items-start">
            {plans.map((plan, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className={cn(
                  "relative p-8 rounded-[2.5rem] border transition-all flex flex-col h-full",
                  plan.highlight 
                    ? "bg-white border-primary shadow-2xl shadow-primary/10 scale-105 z-10" 
                    : "bg-surface-container-lowest border-outline-variant/10 hover:border-primary/30"
                )}
              >
                {plan.highlight && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white px-6 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-primary/20">
                    Most Popular
                  </div>
                )}
                
                <div className="mb-8">
                  <h3 className="text-2xl font-headline font-bold mb-4">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="text-5xl font-black text-on-surface tracking-tighter">{plan.price}</span>
                    <span className="text-on-surface-variant font-bold text-sm uppercase tracking-widest">/ month</span>
                  </div>
                  <p className="text-sm text-on-surface-variant leading-relaxed font-medium">{plan.description}</p>
                </div>

                <div className="h-px bg-outline-variant/10 w-full mb-8"></div>

                <ul className="space-y-4 mb-10 flex-1">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-start gap-3 group">
                      <div className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-primary group-hover:text-white transition-colors">
                        <Check className="w-3 h-3" />
                      </div>
                      <span className="text-sm text-on-surface-variant font-medium">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button 
                  onClick={() => handleUpgrade(plan.id)}
                  disabled={plan.current || upgrading !== null}
                  className={cn(
                    "w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2 text-lg shadow-lg",
                    plan.current ? "bg-primary/10 text-primary cursor-default shadow-none" : 
                    plan.highlight ? "primary-gradient text-white shadow-primary/20 hover:scale-[1.02] active:scale-95" : 
                    "bg-surface-container-high text-on-surface hover:bg-slate-200 shadow-slate-200/50 active:scale-95"
                  )}
                >
                  {upgrading === plan.id ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      {plan.button}
                      {!plan.current && <ArrowRight className="w-5 h-5" />}
                    </>
                  )}
                </button>
              </motion.div>
            ))}
          </div>

          {/* Trust Badges */}
          <div className="mt-32 grid md:grid-cols-3 gap-12 border-t border-outline-variant/10 pt-20">
            {[
              { icon: Shield, title: 'Safe & Secure', desc: 'We use military-grade encryption and human-like behavior simulation to protect your account.' },
              { icon: Zap, title: 'Fast Enrichment', desc: 'Get verified emails and phone numbers in seconds, not hours, with our proprietary engine.' },
              { icon: Users, title: 'Team Ready', desc: 'Collaborate with your team members on shared lead lists and campaigns with ease.' },
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-sm">
                  <item.icon className="w-8 h-8" />
                </div>
                <h4 className="font-headline font-bold text-xl mb-3">{item.title}</h4>
                <p className="text-sm text-on-surface-variant leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          {/* FAQ Section Preview */}
          <div className="mt-32 bg-slate-900 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-headline font-black text-white mb-6">Have more questions?</h2>
              <p className="text-slate-400 text-lg mb-10 max-w-xl mx-auto">Our support team is ready to help you find the perfect plan for your firm. We've helped hundreds of firms scale with LinkedIn Automator.</p>
              <Link to="/help" className="inline-flex items-center gap-2 px-10 py-5 bg-white text-slate-900 rounded-2xl font-bold text-xl hover:bg-primary hover:text-white transition-all shadow-xl shadow-white/5">
                Visit Help Center <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] -mr-48 -mt-48"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/20 blur-[120px] -ml-48 -mb-48"></div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}

