import { Search, Filter, Download, ChevronLeft, ChevronRight, X, RefreshCw, Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useState, useMemo } from 'react';

const initialLogs = [
  { id: 1, type: 'Connection', lead: 'John Doe', company: 'Design Studio', status: 'Success', time: '2026-04-13 10:15 AM' },
  { id: 2, type: 'Scrape', lead: 'Sarah Smith', company: 'BuildIT', status: 'Success', time: '2026-04-13 10:03 AM' },
  { id: 3, type: 'Message', lead: 'Michael Chen', company: 'Tech Corp', status: 'Pending', time: '2026-04-13 09:22 AM' },
  { id: 4, type: 'Enrich', lead: 'Emily Watson', company: 'Urban Planners', status: 'Success', time: '2026-04-13 08:45 AM' },
  { id: 5, type: 'Connection', lead: 'Robert Brown', company: 'Arch Group', status: 'Failed', time: '2026-04-13 08:12 AM', error: 'LinkedIn limit reached' },
  { id: 6, type: 'Message', lead: 'Jessica Lee', company: 'Future Homes', status: 'Success', time: '2026-04-13 07:55 AM' },
];

export default function ActivityLogs() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [logs, setLogs] = useState(initialLogs);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      const newLog = {
        id: Date.now(),
        type: 'Scrape',
        lead: 'New Discovery',
        company: 'Architectural Digest',
        status: 'Success',
        time: new Date().toLocaleString()
      };
      setLogs([newLog, ...logs]);
    }, 1500);
  };

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      alert('Logs exported successfully!');
    }, 2000);
  };

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const matchesSearch = log.lead.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           log.company.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filterType === 'All' || log.type === filterType;
      return matchesSearch && matchesFilter;
    });
  }, [searchTerm, filterType, logs]);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h2 className="text-3xl font-headline font-extrabold text-on-surface tracking-tight">Activity Logs</h2>
          <p className="text-on-surface-variant mt-1">Detailed history of all automated actions and system events.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2 px-4 py-2 bg-surface-container-lowest border border-outline-variant/10 rounded-lg text-sm font-bold hover:bg-surface-container transition-colors disabled:opacity-50"
          >
            <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
            Refresh
          </button>
          <button 
            onClick={handleExport}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:opacity-90 transition-opacity shadow-lg shadow-primary/20 disabled:opacity-50"
          >
            {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            Export Logs
          </button>
        </div>
      </div>

      <div className="bg-surface-container-lowest rounded-2xl border border-outline-variant/10 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-outline-variant/5 flex flex-wrap gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search leads or companies..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-surface-container-low border-none rounded-lg text-sm outline-none focus:ring-2 focus:ring-primary/20" 
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          
          <div className="flex gap-2">
            {['All', 'Connection', 'Message', 'Scrape', 'Enrich'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={cn(
                  "px-4 py-2 rounded-lg text-xs font-bold transition-all",
                  filterType === type 
                    ? "bg-primary text-white shadow-md" 
                    : "bg-surface-container-low text-on-surface-variant hover:bg-surface-container-high"
                )}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low/50 text-[10px] font-bold uppercase tracking-widest text-on-surface-variant">
                <th className="px-6 py-4">Event Type</th>
                <th className="px-6 py-4">Lead / Subject</th>
                <th className="px-6 py-4">Company</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-outline-variant/5">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-surface-container-low/30 transition-colors">
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                      log.type === 'Connection' ? 'bg-blue-100 text-blue-700' :
                      log.type === 'Message' ? 'bg-purple-100 text-purple-700' :
                      log.type === 'Scrape' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                    )}>
                      {log.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-bold text-sm">{log.lead}</td>
                  <td className="px-6 py-4 text-sm text-on-surface-variant">{log.company}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        log.status === 'Success' ? 'bg-green-500' :
                        log.status === 'Pending' ? 'bg-amber-500' : 'bg-red-500'
                      )}></div>
                      <span className="text-xs font-medium">{log.status}</span>
                    </div>
                    {log.error && <p className="text-[10px] text-red-500 mt-1">{log.error}</p>}
                  </td>
                  <td className="px-6 py-4 text-xs text-on-surface-variant font-mono">{log.time}</td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center text-on-surface-variant italic">
                    No logs found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-surface-container-low/30 flex items-center justify-between">
          <p className="text-xs text-on-surface-variant">Showing {filteredLogs.length} events</p>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-surface-container-high rounded-lg transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button className="p-2 hover:bg-surface-container-high rounded-lg transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
