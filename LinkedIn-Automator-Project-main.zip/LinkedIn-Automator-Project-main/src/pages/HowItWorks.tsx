import React from 'react';
import { motion } from 'motion/react';
import { Search, UserPlus, MessageSquare, BarChart3, ArrowRight, Zap, ChevronRight, CheckCircle2 } from 'lucide-react';
import PublicLayout from '@/src/components/PublicLayout';
import { Link } from 'react-router-dom';
import { MockWorkflow, MockScraper, MockEnrichment, MockAnalytics } from '@/src/components/MockDashboard';
import { cn } from '@/src/lib/utils';

const steps = [
  {
    icon: Search,
    title: 'Discover Leads',
    description: 'Use our Smart Scraper to extract thousands of high-quality leads from LinkedIn search results or Sales Navigator.',
    tip: 'Filter by job title, firm size, and location for surgical precision.',
    component: MockScraper
  },
  {
    icon: Zap,
    title: 'Enrich Data',
    description: 'Automatically find verified work emails and project history for every lead in your list.',
    tip: 'Our engine verifies every email to ensure 99% deliverability.',
    component: MockEnrichment
  },
  {
    icon: UserPlus,
    title: 'Automate Outreach',
    description: 'Set up multi-step sequences with personalized connection requests and follow-up messages.',
    tip: 'Use AI personalization to mention specific accomplishments from their profile.',
    component: MockWorkflow
  },
  {
    icon: BarChart3,
    title: 'Analyze & Scale',
    description: 'Monitor your reply rates and conversion funnel. Optimize your messaging based on real-time data.',
    tip: 'A/B test different subject lines and message references.',
    component: MockAnalytics
  }
];

export default function HowItWorks() {
  return (
    <PublicLayout>
      <div className="relative overflow-hidden pt-32 pb-24 px-6">
        {/* Background Decorative Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-5xl md:text-6xl font-headline font-black text-on-surface mb-6 tracking-tighter">
                Your path to <br />
                <span className="text-primary">Automated Growth.</span>
              </h1>
              <p className="text-on-surface-variant max-w-2xl mx-auto text-lg leading-relaxed font-medium">
                Four simple steps to transform your outreach from manual struggle to automated success.
              </p>
            </motion.div>
          </div>

          <div className="space-y-12 relative">
            {/* Vertical Line Connector */}
            <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-outline-variant/20 -translate-x-1/2 hidden md:block"></div>

            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={cn(
                  "relative flex flex-col md:flex-row items-center gap-8 md:gap-16",
                  i % 2 === 1 ? "md:flex-row-reverse" : ""
                )}
              >
                {/* Step Number Circle */}
                <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-white border-4 border-primary shadow-xl z-10 flex items-center justify-center font-black text-primary hidden md:flex">
                  {i + 1}
                </div>

                <div className="flex-1 w-full">
                  <div className="bg-white p-10 rounded-[2.5rem] border border-outline-variant/10 shadow-sm hover:shadow-2xl hover:shadow-primary/5 transition-all group">
                    <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-sm">
                      <step.icon className="w-8 h-8" />
                    </div>
                    <h3 className="text-2xl font-headline font-bold mb-4">{step.title}</h3>
                    <p className="text-on-surface-variant leading-relaxed mb-6 font-medium">{step.description}</p>
                    <div className="p-4 bg-surface-container-low rounded-xl border border-outline-variant/10">
                      <p className="text-[10px] font-bold text-primary uppercase tracking-widest mb-1">Pro Tip</p>
                      <p className="text-xs text-on-surface-variant italic">{step.tip}</p>
                    </div>
                  </div>
                </div>

                <div className="flex-1 hidden md:block">
                  <div className="p-8 bg-surface-container-low rounded-3xl border border-outline-variant/10 shadow-lg">
                    <step.component />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>


          {/* Detailed Workflow Section */}
          <div className="mt-32 bg-surface-container-low rounded-[3rem] p-12 md:p-20">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-4xl font-headline font-black mb-6">The "Set & Forget" Workflow</h2>
                <p className="text-on-surface-variant text-lg leading-relaxed mb-8 font-medium">
                  Once you've defined your targeting and messaging, LinkedIn Automator works in the background. It finds new leads that match your criteria every day and starts the conversation for you.
                </p>
                <div className="space-y-4">
                  {[
                    'Automated Daily Scrapes',
                    'Smart Sequence Triggers',
                    'CRM Integration (Coming Soon)',
                    'Safety Cooldown Management'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-on-surface">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-white p-8 rounded-3xl shadow-2xl border border-outline-variant/10">
                <div className="flex items-center justify-between mb-8">
                  <h4 className="font-headline font-bold">Live Sequence</h4>
                  <span className="px-3 py-1 bg-green-100 text-green-600 text-[10px] font-bold rounded-full uppercase">Running</span>
                </div>
                <div className="space-y-6">
                  <div className="flex items-center gap-4 opacity-50">
                    <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold">1</div>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full"></div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold shadow-lg shadow-primary/20">2</div>
                    <div className="flex-1 h-2 bg-primary/20 rounded-full overflow-hidden">
                      <div className="w-2/3 h-full bg-primary"></div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 opacity-30">
                    <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold">3</div>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full"></div>
                  </div>
                </div>
                <div className="mt-8 pt-8 border-t border-outline-variant/10">
                  <p className="text-xs text-on-surface-variant font-medium">Next action: Send Follow-up Message in 2 hours</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-32 bg-slate-900 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-4xl md:text-5xl font-headline font-black text-white mb-6">Start your growth journey</h2>
              <p className="text-slate-400 text-lg mb-10 max-w-xl mx-auto">Join 500+ firms using LinkedIn Automator to fill their project pipeline.</p>
              <Link to="/login" className="inline-flex items-center gap-2 px-10 py-5 bg-white text-slate-900 rounded-2xl font-bold text-xl hover:bg-primary hover:text-white transition-all shadow-xl shadow-white/5">
                Get Started for Free <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] -mr-48 -mt-48"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/20 blur-[120px] -ml-48 -mb-48"></div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}

