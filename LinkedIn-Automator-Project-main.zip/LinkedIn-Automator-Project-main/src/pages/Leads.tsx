import { Link } from 'react-router-dom';
import { Search, Filter, Download, Trash2, Mail, CheckSquare, Square, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/src/lib/utils';

const initialLeads = [
  { id: 1, name: 'Sarah Jenkins', email: 's.jenkins@metatech.com', title: 'Senior Technical Architect', company: 'MetaTech Solutions', location: 'San Francisco, CA', status: 'Enriched', avatar: 'https://picsum.photos/seed/sarah/100' },
  { id: 2, name: 'David Miller', email: 'd.miller@urbanarc.io', title: 'VP of Engineering & Design', company: 'Urban Architecture Collective', location: 'London, UK', status: 'Scraped', avatar: 'https://picsum.photos/seed/david/100' },
  { id: 3, name: 'Elena Rodriguez', email: 'e.rodriguez@vault.com', title: 'Principal Software Architect', company: 'Vault Security Systems', location: 'Madrid, ES', status: 'Connected', avatar: 'https://picsum.photos/seed/elena/100' },
  { id: 4, name: 'Robert King', email: 'r.king@structure.net', title: 'Director of Automation', company: 'Structure AI', location: 'Toronto, CA', status: 'Enriched', avatar: 'https://picsum.photos/seed/robert/100' },
  { id: 5, name: 'Maya Singh', email: 'maya@designbuild.com', title: 'Lead Systems Engineer', company: 'DesignBuild Global', location: 'Mumbai, IN', status: 'Scraped', avatar: 'https://picsum.photos/seed/maya/100' },
];

export default function Leads() {
  const [leads, setLeads] = useState(initialLeads);
  const [selectedLeads, setSelectedLeads] = useState<number[]>([]);

  const toggleSelect = (id: number) => {
    setSelectedLeads(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedLeads.length === leads.length) {
      setSelectedLeads([]);
    } else {
      setSelectedLeads(leads.map(l => l.id));
    }
  };

  const deleteSelected = () => {
    if (window.confirm(`Are you sure you want to delete ${selectedLeads.length} leads?`)) {
      setLeads(prev => prev.filter(l => !selectedLeads.includes(l.id)));
      setSelectedLeads([]);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Table Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
        <div>
          <nav className="flex items-center gap-2 text-xs font-bold text-on-surface-variant mb-2 uppercase tracking-widest">
            <Link to="/app" className="hover:text-primary transition-colors">Workspace</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-primary">LinkedIn Leads</span>
          </nav>
          <h1 className="text-3xl font-extrabold tracking-tight text-on-surface font-headline">LinkedIn Search Export</h1>
          <p className="text-sm text-on-surface-variant mt-1">Manage and enrich leads extracted from your automation workflows.</p>
        </div>
        <div className="flex flex-col items-end gap-3">
          <div className="flex items-center gap-2 bg-surface-container-high px-4 py-2 rounded-lg">
            <span className="text-xs font-bold text-on-surface-variant">Total Results:</span>
            <span className="text-sm font-extrabold text-primary">{leads.length}</span>
            <span className="text-xs text-on-surface-variant">/ 2500 credits</span>
          </div>
          <div className="flex gap-3">
            <Link to="/app/leads/import" className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white text-sm font-bold rounded-lg shadow-lg shadow-primary/20 hover:opacity-90 transition-opacity">
              <span className="material-symbols-outlined text-lg">add</span>
              Import Leads
            </Link>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-surface-container-lowest text-on-surface text-sm font-semibold rounded-lg shadow-sm hover:bg-surface-container transition-colors border border-outline-variant/10">
              <Filter className="w-4 h-4" />
              Filters
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-surface-container-lowest text-on-surface text-sm font-semibold rounded-lg shadow-sm hover:bg-surface-container transition-colors border border-outline-variant/10">
              <Download className="w-4 h-4" />
              Export to CSV
            </button>
          </div>
        </div>
      </div>

      {/* Bulk Actions Bar */}
      {selectedLeads.length > 0 && (
        <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-xl flex items-center justify-between animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-4">
            <span className="text-sm font-bold text-primary">{selectedLeads.length} leads selected</span>
            <div className="h-4 w-[1px] bg-primary/20"></div>
            <button className="flex items-center gap-2 text-xs font-bold text-primary hover:underline">
              <Mail className="w-3.5 h-3.5" />
              Send Message
            </button>
            <button className="flex items-center gap-2 text-xs font-bold text-primary hover:underline">
              <span className="material-symbols-outlined text-sm">rocket_launch</span>
              Add to Campaign
            </button>
          </div>
          <button 
            onClick={deleteSelected}
            className="flex items-center gap-2 px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-bold hover:bg-red-100 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Delete Selected
          </button>
        </div>
      )}

      {/* Data Table Card */}
      <div className="bg-surface-container-lowest rounded-xl shadow-sm overflow-hidden ring-1 ring-outline-variant/10">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low border-b border-outline-variant/10">
                <th className="px-6 py-4 w-10">
                  <button onClick={toggleSelectAll} className="text-on-surface-variant hover:text-primary transition-colors">
                    {selectedLeads.length === leads.length ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
                  </button>
                </th>
                <th className="px-6 py-4 text-[10px] font-bold tracking-widest uppercase text-on-surface-variant">Profile</th>
                <th className="px-6 py-4 text-[10px] font-bold tracking-widest uppercase text-on-surface-variant">Headline & Company</th>
                <th className="px-6 py-4 text-[10px] font-bold tracking-widest uppercase text-on-surface-variant">Location</th>
                <th className="px-6 py-4 text-[10px] font-bold tracking-widest uppercase text-on-surface-variant">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold tracking-widest uppercase text-on-surface-variant text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-outline-variant/10">
              {leads.map((lead) => (
                <tr key={lead.id} className={cn(
                  "hover:bg-surface-container-low transition-colors group",
                  selectedLeads.includes(lead.id) && "bg-primary/5"
                )}>
                  <td className="px-6 py-4">
                    <button onClick={() => toggleSelect(lead.id)} className={cn(
                      "transition-colors",
                      selectedLeads.includes(lead.id) ? "text-primary" : "text-outline-variant group-hover:text-on-surface-variant"
                    )}>
                      {selectedLeads.includes(lead.id) ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5" />}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <img className="w-10 h-10 rounded-full border border-outline-variant/20" src={lead.avatar} alt={lead.name} referrerPolicy="no-referrer" />
                      <div>
                        <p className="text-sm font-bold text-on-surface">{lead.name}</p>
                        <p className="text-xs text-on-surface-variant">{lead.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-on-surface truncate max-w-xs">{lead.title}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="material-symbols-outlined text-[14px] text-primary">apartment</span>
                      <p className="text-xs text-primary font-semibold">{lead.company}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1 text-on-surface-variant">
                      <span className="material-symbols-outlined text-base">location_on</span>
                      <span className="text-xs">{lead.location}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full ${
                      lead.status === 'Enriched' ? 'bg-primary-fixed text-on-primary-fixed-variant' :
                      lead.status === 'Scraped' ? 'bg-secondary-container text-on-secondary-container' :
                      'bg-tertiary-fixed text-on-tertiary-fixed-variant'
                    }`}>
                      {lead.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Link to="/pricing" className="inline-flex items-center gap-2 px-3 py-1.5 bg-surface-container-high text-primary text-xs font-bold rounded-lg hover:bg-primary-container hover:text-white transition-all">
                      <span className="material-symbols-outlined text-sm">alternate_email</span>
                      Discover Email
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        <div className="px-6 py-4 bg-surface-container-low flex items-center justify-between">
          <p className="text-xs font-medium text-on-surface-variant">Showing <span className="text-on-surface font-bold">1-{leads.length}</span> of {leads.length} leads</p>
          <div className="flex items-center gap-2">
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-surface-container-lowest text-on-surface-variant hover:text-primary transition-all">
              <span className="material-symbols-outlined text-lg">chevron_left</span>
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-primary text-white font-bold text-xs">1</button>
            <button className="w-8 h-8 flex items-center justify-center rounded-lg bg-surface-container-lowest text-on-surface-variant hover:text-primary transition-all">
              <span className="material-symbols-outlined text-lg">chevron_right</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
        <div className="bg-surface-container-lowest p-5 rounded-xl ring-1 ring-outline-variant/10">
          <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant mb-1">Enrichment Rate</p>
          <div className="flex items-end justify-between">
            <h3 className="text-2xl font-extrabold text-on-surface font-headline">68.2%</h3>
            <span className="text-[10px] font-bold text-primary bg-primary-fixed px-2 py-0.5 rounded-full">+4.2%</span>
          </div>
          <div className="w-full h-1.5 bg-surface-container-high mt-4 rounded-full overflow-hidden">
            <div className="h-full bg-primary" style={{ width: '68%' }}></div>
          </div>
        </div>
        <div className="bg-surface-container-lowest p-5 rounded-xl ring-1 ring-outline-variant/10">
          <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant mb-1">Email Success</p>
          <div className="flex items-end justify-between">
            <h3 className="text-2xl font-extrabold text-on-surface font-headline">91.0%</h3>
            <span className="text-[10px] font-bold text-primary bg-primary-fixed px-2 py-0.5 rounded-full">Optimal</span>
          </div>
          <div className="w-full h-1.5 bg-surface-container-high mt-4 rounded-full overflow-hidden">
            <div className="h-full primary-gradient" style={{ width: '91%' }}></div>
          </div>
        </div>
        <div className="bg-surface-container-lowest p-5 rounded-xl ring-1 ring-outline-variant/10">
          <p className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant mb-1">Avg. Connection</p>
          <div className="flex items-end justify-between">
            <h3 className="text-2xl font-extrabold text-on-surface font-headline">1.4d</h3>
            <span className="text-[10px] font-bold text-on-tertiary-fixed-variant bg-tertiary-fixed px-2 py-0.5 rounded-full">Slow</span>
          </div>
          <div className="w-full h-1.5 bg-surface-container-high mt-4 rounded-full overflow-hidden">
            <div className="h-full bg-tertiary" style={{ width: '35%' }}></div>
          </div>
        </div>
        <div className="bg-primary text-white p-5 rounded-xl shadow-lg shadow-primary/20 relative overflow-hidden">
          <div className="relative z-10">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/70 mb-1">Credits Remaining</p>
            <h3 className="text-2xl font-extrabold font-headline">1,658</h3>
            <p className="text-[10px] mt-4 font-bold text-white/90">Renew in 12 days</p>
          </div>
          <span className="material-symbols-outlined absolute -bottom-4 -right-4 text-8xl opacity-10 rotate-12">account_balance_wallet</span>
        </div>
      </div>
    </div>
  );
}
