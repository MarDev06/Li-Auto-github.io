import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Zap, Shield, Globe, Users, MessageSquare, BarChart3, Heart, Star, Quote } from 'lucide-react';
import { motion } from 'motion/react';
import PublicLayout from '@/src/components/PublicLayout';
import MockDashboard, { MockWorkflow } from '@/src/components/MockDashboard';

export default function Landing() {
  return (
    <PublicLayout>
      {/* Hero Section */}
      <section className="pt-40 pb-20 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-widest mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              The Human-Centric Automation Platform
            </div>
            <h1 className="text-6xl md:text-7xl font-headline font-black leading-[0.9] tracking-tighter mb-8">
              Grow your <br />
              <span className="text-primary">LinkedIn</span> <br />
              with Integrity.
            </h1>
            <p className="text-xl text-on-surface-variant leading-relaxed mb-10 max-w-lg font-medium">
              Automate your outreach with surgical precision. Find high-quality leads, enrich data, and send personalized messages that build real relationships.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/login" className="px-8 py-4 primary-gradient text-white rounded-2xl font-bold text-lg shadow-xl shadow-primary/30 hover:scale-105 transition-transform flex items-center justify-center gap-2">
                Start Growing Free <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/pricing" className="px-8 py-4 bg-surface-container-high text-on-surface rounded-2xl font-bold text-lg hover:bg-slate-200 transition-colors flex items-center justify-center">
                View Pricing
              </Link>
            </div>
            <div className="mt-12 flex items-center gap-8 opacity-60">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-slate-200"></div>
                  ))}
                </div>
                <span className="text-xs font-bold text-on-surface-variant">500+ Firms Trusted Us</span>
              </div>
              <div className="h-4 w-px bg-outline-variant/30"></div>
              <div className="flex items-center gap-1 text-yellow-500">
                <Star className="w-4 h-4 fill-current" />
                <span className="text-xs font-bold text-on-surface-variant">4.9/5 Rating</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <MockDashboard />
            {/* Decorative Elements */}
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-primary/20 blur-[100px] rounded-full -z-10"></div>
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-secondary/20 blur-[100px] rounded-full -z-10"></div>
          </motion.div>
        </div>
      </section>

      {/* Wholesome Section: Why Us */}
      <section className="py-24 bg-primary/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-outline-variant/10 flex flex-col h-full">
                  <Heart className="w-10 h-10 text-red-500 mb-4" />
                  <h4 className="font-bold mb-2">Built for Humans</h4>
                  <p className="text-sm text-on-surface-variant">We prioritize real connections over spammy volume.</p>
                </div>
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-outline-variant/10 flex flex-col h-full">
                  <Shield className="w-10 h-10 text-primary mb-4" />
                  <h4 className="font-bold mb-2">Safety First</h4>
                  <p className="text-sm text-on-surface-variant">Your account health is our top priority, always.</p>
                </div>
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-outline-variant/10 flex flex-col h-full">
                  <Star className="w-10 h-10 text-yellow-500 mb-4" />
                  <h4 className="font-bold mb-2">Quality Leads</h4>
                  <p className="text-sm text-on-surface-variant">Find the right people, not just more people.</p>
                </div>
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-outline-variant/10 flex flex-col h-full">
                  <Zap className="w-10 h-10 text-primary mb-4" />
                  <h4 className="font-bold mb-2">Smart Growth</h4>
                  <p className="text-sm text-on-surface-variant">Scale your firm with intelligent automation.</p>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-4xl md:text-5xl font-headline font-black tracking-tight mb-8 leading-tight">
                Why LinkedIn <br />
                <span className="text-primary">Automator?</span>
              </h2>
              <p className="text-lg text-on-surface-variant leading-relaxed mb-8 font-medium">
                We believe that automation shouldn't feel robotic. Our platform is designed to help you scale your personal touch, not replace it. We help you find the right people and start meaningful conversations that lead to real business growth.
              </p>
              <ul className="space-y-4">
                {[
                  'Human-like behavior simulation',
                  'AI-driven personalization that works',
                  'Deep industry-specific lead enrichment',
                  'Transparent analytics and reporting'
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 font-bold text-on-surface">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 bg-surface-container-low/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-headline font-black tracking-tight mb-4">Everything you need to scale</h2>
            <p className="text-on-surface-variant max-w-2xl mx-auto font-medium">Powerful tools designed specifically for high-growth firms and professional networks.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Zap, title: 'Smart Scraper', desc: 'Extract high-quality leads from LinkedIn search results with one click.' },
              { icon: Globe, title: 'Email Discovery', desc: 'Find verified work emails for any lead automatically.' },
              { icon: Users, title: 'Auto-Connect', desc: 'Send personalized connection requests with smart templates.' },
              { icon: MessageSquare, title: 'AI Personalization', desc: 'Our AI analyzes profiles to write messages that sound like you.' },
              { icon: Shield, title: 'Safety First', desc: 'Human-like behavior simulation to keep your account safe.' },
              { icon: BarChart3, title: 'Deep Analytics', desc: 'Track every interaction and optimize your outreach strategy.' },
            ].map((feat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-surface-container-lowest p-8 rounded-3xl border border-outline-variant/10 hover:border-primary/30 transition-all group"
              >
                <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <feat.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feat.title}</h3>
                <p className="text-on-surface-variant leading-relaxed font-medium">{feat.desc}</p>
              </motion.div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link to="/features" className="inline-flex items-center gap-2 text-primary font-bold hover:gap-3 transition-all">
              Explore all features <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Preview */}
      <section id="how-it-works" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-headline font-black tracking-tight mb-8">
                How it <span className="text-primary">Works</span>
              </h2>
              <div className="space-y-8">
                {[
                  { step: '01', title: 'Discover', desc: 'Scrape high-quality leads from LinkedIn with one click.' },
                  { step: '02', title: 'Enrich', desc: 'Find verified emails and project history automatically.' },
                  { step: '03', title: 'Automate', desc: 'Send personalized AI-driven outreach sequences.' }
                ].map((item, i) => (
                  <div key={i} className="flex gap-6">
                    <span className="text-4xl font-headline font-black text-primary/20">{item.step}</span>
                    <div>
                      <h4 className="text-xl font-bold mb-2">{item.title}</h4>
                      <p className="text-on-surface-variant font-medium">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-12">
                <Link to="/how-it-works" className="px-8 py-4 primary-gradient text-white rounded-2xl font-bold text-lg shadow-xl shadow-primary/30 hover:scale-105 transition-transform inline-flex items-center gap-2">
                  Learn the Process <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
            </motion.div>
            <div className="relative p-12 bg-surface-container-low rounded-[3rem] border border-outline-variant/10 shadow-2xl">
              <MockWorkflow />
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-primary/10 blur-[60px] rounded-full"></div>
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-secondary/10 blur-[100px] rounded-full"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-surface-container-lowest">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-headline font-black tracking-tight mb-4">Loved by Growth Teams</h2>
            <p className="text-on-surface-variant max-w-2xl mx-auto font-medium">Real stories from real firms scaling their outreach with integrity.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: 'Sarah Miller', role: 'Growth Lead @ ArchStudio', quote: 'LinkedIn Automator transformed our outreach. We went from 2 replies a week to 15+ meaningful conversations.' },
              { name: 'David Chen', role: 'Principal @ UrbanDesign', quote: 'The AI personalization is incredible. It actually sounds like me and references real projects from the leads portfolio.' },
              { name: 'Elena Rodriguez', role: 'Marketing Director @ BuildTech', quote: 'Safety was our biggest concern. This platform is the only one we trust with our team members LinkedIn accounts.' }
            ].map((t, i) => (
              <div key={i} className="bg-surface-container-low p-8 rounded-3xl border border-outline-variant/10 relative">
                <Quote className="absolute top-6 right-6 w-8 h-8 text-primary/10" />
                <p className="text-on-surface-variant italic mb-6 font-medium leading-relaxed">"{t.quote}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10"></div>
                  <div>
                    <p className="font-bold text-sm">{t.name}</p>
                    <p className="text-[10px] text-on-surface-variant uppercase font-bold tracking-widest">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto bg-slate-900 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-headline font-black text-white mb-6">Ready to automate your growth?</h2>
            <p className="text-slate-400 text-lg mb-10 max-w-xl mx-auto">Join 500+ firms using LinkedIn Automator to fill their project pipeline.</p>
            <Link to="/login" className="inline-flex px-10 py-5 bg-white text-slate-900 rounded-2xl font-bold text-xl hover:bg-primary hover:text-white transition-all shadow-xl shadow-white/5">
              Get Started for Free
            </Link>
            <p className="text-slate-500 mt-6 text-sm">No credit card required • 14-day free trial</p>
          </div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/20 blur-[120px] -ml-48 -mb-48"></div>
        </div>
      </section>
    </PublicLayout>
  );
}

