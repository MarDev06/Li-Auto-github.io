import { User, Mail, Shield, CreditCard, Bell, LogOut, Loader2, Check } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/src/lib/utils';

export default function Account() {
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const navigate = useNavigate();

  const handleSave = () => {
    setSaving(true);
    setSaved(false);
    setTimeout(() => {
      setSaving(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }, 1500);
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    navigate('/');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-10">
        <h2 className="text-3xl font-headline font-extrabold text-on-surface tracking-tight">Account Settings</h2>
        <p className="text-on-surface-variant mt-1">Manage your profile, subscription, and security preferences.</p>
      </div>

      <div className="grid md:grid-cols-12 gap-8">
        <div className="md:col-span-4 space-y-4">
          <div className="bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/10 shadow-sm text-center">
            <div className="relative inline-block mb-4">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuB5X0X4hUc2FOFJgHOVNZRrqykHRfCy0GIw5JGPcjtAqBg2bo86om1BUfhFj9gQatXpYF6NxPFjZqc-CYbeg0CsG-fnhKBp03UHRMYdGtNdq-PoIqn4t0cBS8vU8GJ7WUkbsVvAQ3BnW5-VpNvAlLG_B-uGtxgPW68K2LhcwO43UCl9H_vOWE4Xf8r3ZnRRzlN1MEEI5XC9EHqCx40m4BMH5f_vib2Lztbhb1PfB0DV4-WCNcQ1-j3OZ6BH86wZs27xsLBKL2PkFKs" 
                alt="Profile" 
                className="w-24 h-24 rounded-full border-4 border-white shadow-md mx-auto"
                referrerPolicy="no-referrer"
              />
              <button className="absolute bottom-0 right-0 p-2 bg-primary text-white rounded-full shadow-lg hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-sm">edit</span>
              </button>
            </div>
            <h3 className="font-bold text-xl">Alex Chen</h3>
            <p className="text-sm text-on-surface-variant">ssmore97@gmail.com</p>
            <div className="mt-4 px-4 py-1.5 bg-primary-fixed text-on-primary-fixed-variant rounded-full text-[10px] font-bold uppercase tracking-widest inline-block">
              Pro Member
            </div>
          </div>

          <nav className="bg-surface-container-lowest rounded-2xl border border-outline-variant/10 shadow-sm overflow-hidden">
            {[
              { icon: User, label: 'Profile Information' },
              { icon: Bell, label: 'Notifications' },
              { icon: Shield, label: 'Security' },
              { icon: CreditCard, label: 'Billing & Plans' },
            ].map((item, i) => (
              <button key={i} className="w-full flex items-center gap-3 px-6 py-4 text-sm font-medium text-on-surface-variant hover:bg-surface-container-low hover:text-primary transition-all border-b border-outline-variant/5 last:border-0">
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-6 py-4 text-sm font-medium text-red-500 hover:bg-red-50 transition-all"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </nav>
        </div>

        <div className="md:col-span-8 space-y-6">
          <section className="bg-surface-container-lowest p-8 rounded-2xl border border-outline-variant/10 shadow-sm">
            <h3 className="font-bold text-lg mb-6">Profile Information</h3>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-on-surface-variant uppercase tracking-tighter">Full Name</label>
                <input type="text" defaultValue="Alex Chen" className="w-full px-4 py-2.5 bg-surface-container-low border-none rounded-lg text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-on-surface-variant uppercase tracking-tighter">Email Address</label>
                <input type="email" defaultValue="ssmore97@gmail.com" className="w-full px-4 py-2.5 bg-surface-container-low border-none rounded-lg text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div className="col-span-2 space-y-2">
                <label className="text-xs font-bold text-on-surface-variant uppercase tracking-tighter">Professional Headline</label>
                <input type="text" defaultValue="Senior Technical Architect | SaaS Growth Expert" className="w-full px-4 py-2.5 bg-surface-container-low border-none rounded-lg text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
            </div>
            <div className="mt-8 flex justify-end">
              <button 
                onClick={handleSave}
                disabled={saving}
                className={cn(
                  "px-8 py-2.5 font-bold rounded-xl transition-all shadow-lg flex items-center gap-2 min-w-[160px] justify-center",
                  saved ? "bg-green-500 text-white shadow-green-200" : "bg-primary text-white shadow-primary/20 hover:opacity-90"
                )}
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : saved ? (
                  <>
                    <Check className="w-4 h-4" />
                    Saved!
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </section>

          <section className="bg-surface-container-lowest p-8 rounded-2xl border border-outline-variant/10 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-lg">Current Plan</h3>
              <span className="text-primary font-bold text-sm cursor-pointer hover:underline">Manage Subscription</span>
            </div>
            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-outline-variant/10">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="font-bold text-xl">Pro Plan</h4>
                  <p className="text-sm text-on-surface-variant">$49 / month • Billed Monthly</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-primary">Active</p>
                  <p className="text-[10px] text-on-surface-variant uppercase font-bold">Next billing: May 12, 2026</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-on-surface-variant">Lead Credits Used</span>
                  <span className="text-on-surface">842 / 2,500</span>
                </div>
                <div className="w-full h-2 bg-surface-container-high rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: '33.6%' }}></div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
