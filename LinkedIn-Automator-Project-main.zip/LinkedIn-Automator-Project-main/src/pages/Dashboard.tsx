import { cn } from '@/src/lib/utils';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header Section */}
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-extrabold font-headline text-on-surface tracking-tight">Performance Workspace</h2>
          <p className="text-on-surface-variant mt-1">Live overview of your LinkedIn automation ecosystem.</p>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/app/campaigns/new" className="px-6 py-2.5 rounded-lg font-semibold text-white primary-gradient shadow-xl shadow-primary/30 hover:scale-[1.02] transition-transform flex items-center gap-2">
            <span className="material-symbols-outlined text-sm">add</span>
            New Campaign
          </Link>
          <div className="bg-surface-container-high px-4 py-2 rounded-lg flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            <span className="text-xs font-bold text-on-surface-variant font-sans tracking-wide uppercase">System Healthy</span>
          </div>
        </div>
      </div>

      {/* Quick Access Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'AI Insights', path: '/app/insights', icon: 'auto_awesome', color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Activity Logs', path: '/app/activity', icon: 'history', color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Notifications', path: '/app/notifications', icon: 'notifications', color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Pricing & Plans', path: '/pricing', icon: 'payments', color: 'text-green-600', bg: 'bg-green-50' },
        ].map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className="flex items-center gap-3 p-4 bg-surface-container-lowest rounded-xl border border-outline-variant/10 hover:border-primary/30 hover:shadow-md transition-all group"
          >
            <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110", item.bg, item.color)}>
              <span className="material-symbols-outlined">{item.icon}</span>
            </div>
            <span className="font-bold text-sm text-on-surface">{item.label}</span>
          </Link>
        ))}
      </div>

      {/* Bento Grid Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Total Leads */}
        <Link to="/app/leads" className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/10 transition-all hover:shadow-lg group">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 bg-secondary-container text-on-secondary-container rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined">database</span>
            </div>
            <span className="text-green-600 text-xs font-bold bg-green-50 px-2 py-1 rounded">+12%</span>
          </div>
          <p className="text-outline-variant uppercase tracking-widest text-[10px] mb-1 font-bold">Total Leads Scraped</p>
          <h3 className="text-3xl font-bold font-headline text-on-surface">12,482</h3>
        </Link>

        {/* Active Campaigns */}
        <Link to="/app/campaigns" className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/10 transition-all hover:shadow-lg group">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 bg-primary-container/10 text-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined">rocket_launch</span>
            </div>
            <span className="text-on-surface-variant text-xs font-medium">8 Running</span>
          </div>
          <p className="text-outline-variant uppercase tracking-widest text-[10px] mb-1 font-bold">Active Campaigns</p>
          <h3 className="text-3xl font-bold font-headline text-on-surface">24</h3>
        </Link>

        {/* Connection Gauge */}
        <div className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/10 transition-all hover:shadow-lg relative overflow-hidden">
          <div className="flex flex-col items-center justify-center">
            <div className="relative w-24 h-24">
              <svg className="w-full h-full transform -rotate-90">
                <circle className="text-surface-container-high" cx="48" cy="48" fill="transparent" r="40" stroke="currentColor" strokeWidth="8"></circle>
                <circle className="text-primary-container" cx="48" cy="48" fill="transparent" r="40" stroke="currentColor" strokeDasharray="251.2" strokeDashoffset="0" strokeWidth="8"></circle>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold font-headline">20</span>
                <span className="text-[8px] uppercase font-bold text-outline-variant">Limit</span>
              </div>
            </div>
            <p className="mt-4 text-outline-variant uppercase tracking-widest text-[10px] font-bold">Connection Limit</p>
            <p className="text-sm font-bold text-on-surface mt-1">20/20 Daily</p>
          </div>
        </div>

        {/* Profile Views */}
        <div className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/10 transition-all hover:shadow-lg">
          <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 bg-tertiary-fixed text-on-tertiary-fixed-variant rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined">visibility</span>
            </div>
          </div>
          <p className="text-outline-variant uppercase tracking-widest text-[10px] mb-1 font-bold">Profile Views</p>
          <h3 className="text-3xl font-bold font-headline text-on-surface">432</h3>
          <div className="mt-4 h-1.5 w-full bg-surface-container-high rounded-full overflow-hidden">
            <div className="h-full bg-tertiary w-[65%]"></div>
          </div>
        </div>
      </div>

      {/* Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity Feed */}
        <div className="lg:col-span-2 bg-surface-container-lowest rounded-xl border border-outline-variant/10 overflow-hidden">
          <div className="px-6 py-5 border-b border-outline-variant/5 flex justify-between items-center">
            <h4 className="text-lg font-bold font-headline">Recent Activity</h4>
            <Link to="/app/activity" className="text-primary text-xs font-bold hover:underline">View All Logs</Link>
          </div>
          <div className="divide-y divide-outline-variant/5">
            {[
              { type: 'person_add', title: 'Connected with John Doe', desc: 'Lead Architect at Design Studio • 2m ago', status: 'SUCCESS', color: 'green' },
              { type: 'pageview', title: 'Profile Scraped: Sarah Smith', desc: 'Project Manager at BuildIT • 14m ago', status: 'SUCCESS', color: 'blue' },
              { type: 'mail', title: 'InMail Sent to Michael Chen', desc: 'Regional Director • 1h ago', status: 'PENDING', color: 'orange' },
              { type: 'person_add', title: 'Connected with Emily Watson', desc: 'Senior Planner • 3h ago', status: 'SUCCESS', color: 'green' },
            ].map((item, i) => (
              <div key={i} className="px-6 py-4 flex items-center gap-4 hover:bg-surface-container-low transition-colors">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center",
                  item.color === 'green' ? 'bg-green-100 text-green-700' :
                  item.color === 'blue' ? 'bg-blue-100 text-blue-700' :
                  'bg-orange-100 text-orange-700'
                )}>
                  <span className="material-symbols-outlined text-sm">{item.type}</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-on-surface">{item.title}</p>
                  <p className="text-xs text-on-surface-variant">{item.desc}</p>
                </div>
                <div className="px-2 py-1 bg-primary-fixed text-on-primary-fixed-variant rounded text-[10px] font-bold">{item.status}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Safety Health & Insights */}
        <div className="space-y-8">
          {/* Safety Health Widget */}
          <div className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/10 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-bold font-headline">Safety Health</h4>
              <span className="material-symbols-outlined text-green-600" style={{ fontVariationSettings: "'FILL' 1" }}>verified_user</span>
            </div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
              <div>
                <p className="text-sm font-bold text-on-surface">Account is secure</p>
                <p className="text-xs text-on-surface-variant">Operating within LinkedIn limits</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-on-surface-variant">Cooldown Period</span>
                <span className="text-on-surface">None Active</span>
              </div>
              <div className="flex justify-between text-xs font-medium">
                <span className="text-on-surface-variant">Search Queries</span>
                <span className="text-on-surface">14/100</span>
              </div>
              <div className="h-2 w-full bg-surface-container-high rounded-full overflow-hidden">
                <div className="h-full bg-primary-container w-[14%]"></div>
              </div>
            </div>
          </div>

          {/* AI Insights */}
          <div className="glass-panel p-6 rounded-xl border border-primary/10 shadow-xl bg-gradient-to-br from-white to-primary-fixed/30 relative overflow-hidden">
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-primary/5 rounded-full blur-3xl"></div>
            <h4 className="text-sm font-bold text-primary font-headline flex items-center gap-2 mb-3">
              <span className="material-symbols-outlined text-lg">auto_awesome</span>
              Automator Insights
            </h4>
            <p className="text-sm text-on-surface leading-relaxed italic">
              "Your reply rate is <span className="font-bold text-primary">24% higher</span> than average for the 'Architectural Sales' campaign. We suggest increasing your daily scrape limit by 5%."
            </p>
            <Link to="/app/insights" className="mt-4 inline-block text-xs font-bold text-primary bg-white/50 px-4 py-2 rounded-lg border border-primary/10 hover:bg-white transition-colors">
              Apply Strategy
            </Link>
          </div>

          {/* Upgrade Prompt */}
          <div className="relative rounded-xl overflow-hidden group h-40">
            <img
              alt="Dashboard Upgrade"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
              src="https://picsum.photos/seed/architecture/800/400"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent flex flex-col justify-end p-5">
              <p className="text-white text-sm font-bold">Unlock Advanced Targeting</p>
              <p className="text-white/70 text-[10px] mb-2 uppercase tracking-widest">Enterprise Plan Features</p>
              <Link to="/pricing" className="w-fit bg-primary-container text-white px-3 py-1.5 rounded-md text-xs font-bold hover:scale-105 transition-transform">Upgrade Now</Link>
            </div>
          </div>
          {/* System Status Widget */}
          <div className="bg-surface-container-lowest rounded-xl p-6 shadow-sm border border-outline-variant/10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-headline font-bold text-lg">System Status</h3>
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-green-500 uppercase tracking-widest">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                All Systems Operational
              </span>
            </div>
            <div className="space-y-4">
              {[
                { label: 'LinkedIn API', status: 'Healthy', latency: '124ms' },
                { label: 'AI Message Gen', status: 'Healthy', latency: '850ms' },
                { label: 'Lead Scraper', status: 'Healthy', latency: '2.1s' },
              ].map((sys, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-surface-container-low/50">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    <span className="text-sm font-semibold">{sys.label}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-bold text-on-surface-variant block uppercase">{sys.status}</span>
                    <span className="text-[10px] text-outline-variant">{sys.latency}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
