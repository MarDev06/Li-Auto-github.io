import { HelpCircle, Book, MessageSquare, LifeBuoy, ChevronRight, Search, Send, Loader2, Check } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/src/lib/utils';
import PublicLayout from '@/src/components/PublicLayout';
import { motion } from 'motion/react';

const categories = [
  { icon: Book, title: 'Getting Started', description: 'Learn the basics of setting up your first LinkedIn outreach campaign.' },
  { icon: LifeBuoy, title: 'Safety & Limits', description: 'Understand LinkedIn safety limits and how our smart delays protect your account.' },
  { icon: MessageSquare, title: 'Messaging Strategy', description: 'Best practices for writing personalized notes that get leads to reply.' },
];

export default function HelpCenter() {
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleContact = () => {
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setSent(true);
      setTimeout(() => setSent(false), 5000);
    }, 2000);
  };

  return (
    <PublicLayout>
      <div className="relative overflow-hidden pt-32 pb-24 px-6">
        {/* Background Decorative Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-5xl md:text-6xl font-headline font-black text-on-surface mb-6 tracking-tighter">
                How can we <span className="text-primary">help?</span>
              </h1>
              <div className="relative max-w-xl mx-auto">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant w-5 h-5" />
                <input 
                  type="text" 
                  placeholder="Search for articles, guides, and tutorials..." 
                  className="w-full pl-12 pr-4 py-4 bg-white border border-outline-variant/20 rounded-2xl shadow-xl shadow-primary/5 focus:ring-2 focus:ring-primary/20 outline-none transition-all text-lg"
                />
              </div>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-20">
            {categories.map((cat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="bg-white p-8 rounded-3xl border border-outline-variant/10 hover:border-primary/30 transition-all cursor-pointer group shadow-sm hover:shadow-xl hover:shadow-primary/5"
              >
                <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-sm">
                  <cat.icon className="w-7 h-7" />
                </div>
                <h3 className="font-headline font-bold text-xl mb-3">{cat.title}</h3>
                <p className="text-sm text-on-surface-variant leading-relaxed font-medium">{cat.description}</p>
                <div className="mt-6 flex items-center gap-2 text-primary font-bold text-xs uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                  Read More <ChevronRight className="w-4 h-4" />
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-slate-900 rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl"
          >
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
              <div>
                <h3 className="text-3xl font-headline font-black mb-3">Still need help?</h3>
                <p className="text-slate-400 text-lg max-w-md">Our support team is available 24/7 to help you with your LinkedIn campaigns.</p>
              </div>
              <button 
                onClick={handleContact}
                disabled={sending || sent}
                className={cn(
                  "px-10 py-5 font-bold rounded-2xl transition-all flex items-center gap-3 min-w-[220px] justify-center text-lg shadow-xl",
                  sent ? "bg-green-500 text-white shadow-green-500/20" : "bg-white text-slate-900 hover:bg-primary hover:text-white shadow-white/5"
                )}
              >
                {sending ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" />
                    Sending...
                  </>
                ) : sent ? (
                  <>
                    <Check className="w-6 h-6" />
                    Ticket Created
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Contact Support
                  </>
                )}
              </button>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[120px] -mr-48 -mt-48"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/10 blur-[100px] -ml-32 -mb-32"></div>
          </motion.div>
        </div>
      </div>
    </PublicLayout>
  );
}

